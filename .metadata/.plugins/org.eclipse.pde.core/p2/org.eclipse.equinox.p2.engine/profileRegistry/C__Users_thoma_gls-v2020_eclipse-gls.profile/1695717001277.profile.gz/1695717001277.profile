<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='C__Users_thoma_gls-v2020_eclipse-gls' timestamp='1695717001277'>
  <properties size='13'>
    <property name='org.eclipse.equinox.p2.cache' value='C:\Users\thoma\eclipse-workspace-gls\.metadata\.plugins\org.eclipse.pde.core'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32'/>
    <property name='org.eclipse.oomph.p2.profile.type' value='Installation'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='C:\Users\thoma\gls-v2020\eclipse-gls'/>
    <property name='org.eclipse.oomph.p2.profile.definition' value='&lt;p2:ProfileDefinition xmlns:p2=&quot;http://www.eclipse.org/oomph/p2/1.0&quot;&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.platform.ide&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.platform.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.rcp.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;epp.package.modeling&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.acceleo.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.e4.core.tools.feature.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.emf.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.emf.cdo.epp.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.emf.compare.diagram.sirius.source.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.emf.compare.ide.ui.source.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.emf.compare.source.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.emf.ecoretools.design.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.emf.ecoretools.sdk.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.emf.parsley.sdk.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.emf.parsley.sdk.source.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.emf.query.sdk.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.emf.sdk.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.emf.transaction.sdk.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.emf.validation.sdk.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.gef.sdk.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.gmf.runtime.sdk.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.jdt.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.m2m.atl.sdk.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.ocl.all.sdk.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.ocl.examples.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.pde.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.sdk.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.sirius.specifier.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.uml2.sdk.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.xsd.sdk.feature.group&quot;/&gt;&#xD;&#xA;  &lt;requirement name=&quot;org.eclipse.xtext.sdk.feature.group&quot;/&gt;&#xD;&#xA;  &lt;repository url=&quot;http://download.eclipse.org/eclipse/updates/4.18&quot;/&gt;&#xD;&#xA;  &lt;repository url=&quot;http://download.eclipse.org/mmt/atl/updates/releases/4.2.1&quot;/&gt;&#xD;&#xA;  &lt;repository url=&quot;http://download.eclipse.org/modeling/mdt/ocl/updates/releases/6.13.0&quot;/&gt;&#xD;&#xA;  &lt;repository url=&quot;http://download.eclipse.org/releases/2020-09&quot;/&gt;&#xD;&#xA;  &lt;repository url=&quot;http://download.eclipse.org/sirius/updates/releases/6.4.1/2020-09&quot;/&gt;&#xD;&#xA;  &lt;repository url=&quot;http://download.eclipse.org/technology/epp/packages/2020-09&quot;/&gt;&#xD;&#xA;  &lt;repository url=&quot;https://download.eclipse.org/acceleo/updates/releases/3.7&quot;/&gt;&#xD;&#xA;  &lt;repository url=&quot;https://download.eclipse.org/modeling/tmf/xtext/updates/releases/2.24.0&quot;/&gt;&#xD;&#xA;&lt;/p2:ProfileDefinition&gt;'/>
    <property name='eclipse.touchpoint.launcherName' value='eclipse'/>
    <property name='org.eclipse.equinox.p2.cache.extensions' value='file:/C:/Users/thoma/gls-v2020/eclipse-gls/.eclipseextension|file:/C:/Users/thoma/gls-v2020/eclipse-gls/configuration/org.eclipse.osgi/350/data/listener_1925729951/'/>
    <property name='org.eclipse.equinox.p2.surrogate' value='true'/>
    <property name='org.eclipse.equinox.p2.cache.shared' value='C:\Users\thoma\gls-v2020\eclipse-gls'/>
    <property name='org.eclipse.equinox.p2.configurationFolder' value='C:\Users\thoma\eclipse-workspace-gls\.metadata\.plugins\org.eclipse.pde.core\Eclipse Application'/>
    <property name='org.eclipse.equinox.p2.launcherConfiguration' value='C:\Users\thoma\eclipse-workspace-gls\.metadata\.plugins\org.eclipse.pde.core\Eclipse Application\eclipse.ini.ignored'/>
  </properties>
  <units size='38'>
    <unit id='SharedProfile_C__Users_thoma_gls-v2020_eclipse-gls' version='1.0.0.1695221449237' singleton='false' generation='2'>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Shared profile'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='SharedProfile_C__Users_thoma_gls-v2020_eclipse-gls' version='1.0.0.1695221449237'/>
      </provides>
      <requires size='1752'>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ui.feature.group&apos;, version(&apos;2.13.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.runtime&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.source.feature.group&apos;, version(&apos;2.23.0.v20200701-0840&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.builder.standalone&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.doc.user&apos;, version(&apos;4.17.0.v20200831-0727&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launch.source&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.genericeditor.diff.extension.source&apos;, version(&apos;1.0.600.v20200212-1524&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.formatterapp.source&apos;, version(&apos;1.0.0.v20200119-0748&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xpand&apos;, version(&apos;2.2.0.v201605260315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.providers&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.core&apos;, version(&apos;2.3.5.v201308161310&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.win32.x86_64&apos;, version(&apos;1.1.200.v20190812-0919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.renderers.swt&apos;, version(&apos;0.14.1300.v20200829-1411&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.core.sdk.feature.group&apos;, version(&apos;5.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emfforms.core.services&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.edit.source.feature.jar&apos;, version(&apos;1.7.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare&apos;, version(&apos;3.7.1100.v20200611-0145&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.feature.jar&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.builder&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.compiler.apt.source&apos;, version(&apos;1.3.1100.v20200828-0941&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.css.sac.source&apos;, version(&apos;1.3.1.v200903091627&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ui.source.feature.jar&apos;, version(&apos;2.13.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.ide.executable.win32.win32.x86_64.eclipse&apos;, version(&apos;4.17.0.I20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.build&apos;, version(&apos;3.10.800.v20200410-1419&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.universal.source&apos;, version(&apos;3.4.0.v20200805-1259&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.exportmodel.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codemining&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.cli&apos;, version(&apos;1.2.0.v201404270220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xmlgraphics.source&apos;, version(&apos;2.4.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.contexts.source&apos;, version(&apos;1.8.400.v20191217-1710&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.ui&apos;, version(&apos;1.2.0.v20200813-0523&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.jface&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.sdk.feature.jar&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.ui&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.io&apos;, version(&apos;2.6.0.v20190123-2029&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.ui.refactoring.source&apos;, version(&apos;3.11.100.v20200817-1715&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.action.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.directorywatcher.source&apos;, version(&apos;1.2.500.v20191211-1631&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.doc.isv&apos;, version(&apos;3.11.0.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.emfvm.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.ui.shared&apos;, version(&apos;4.4.1.v20200330-1311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.lib.source&apos;, version(&apos;2.23.0.v20200831-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.directorywatcher&apos;, version(&apos;1.2.500.v20191211-1631&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.common.edit&apos;, version(&apos;2.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.purexbase&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.source.feature.group&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.adt.editor.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.core&apos;, version(&apos;3.8.1100.v20200806-0621&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.engine.source&apos;, version(&apos;1.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.runtime&apos;, version(&apos;1.1.0.v20180713-1646&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.preferences.source&apos;, version(&apos;3.8.0.v20200422-1833&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.core&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.constants.source&apos;, version(&apos;1.13.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.runtime&apos;, version(&apos;3.19.0.v20200724-1004&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.pdf&apos;, version(&apos;1.6.0.v201105071520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.source.feature.jar&apos;, version(&apos;3.11.0.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.source&apos;, version(&apos;3.10.400.v20200611-1719&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.standalone&apos;, version(&apos;2.23.0.v20200831-0856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.examples.runtime&apos;, version(&apos;1.9.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.source&apos;, version(&apos;3.118.0.v20200807-0902&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.common.feature.feature.group&apos;, version(&apos;4.17.0.20200910-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi&apos;, version(&apos;3.16.0.v20200828-0759&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.source&apos;, version(&apos;4.13.0.v20200204-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit5.runtime&apos;, version(&apos;1.0.1000.v20200720-0748&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.edit.source&apos;, version(&apos;2.11.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emfforms.core.services.emfspecificservice&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.app.source&apos;, version(&apos;1.5.0.v20200717-0620&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.ui&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.garbagecollector.source&apos;, version(&apos;1.1.400.v20200221-1022&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.mapping.editor.source.feature.group&apos;, version(&apos;2.13.0.v20190323-1100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.examples.runtime.diagram.logic&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.type.core&apos;, version(&apos;1.9.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.core.ant&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.ecore.converter.source&apos;, version(&apos;2.8.0.v20180706-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna&apos;, version(&apos;4.5.1.v20190425-1842&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.printing&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.servlet&apos;, version(&apos;9.4.31.v20200723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.security.source&apos;, version(&apos;9.4.31.v20200723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ui.feature.group&apos;, version(&apos;2.22.0.v20200424-0451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.wizard&apos;, version(&apos;2.23.0.v20200831-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.vintage.engine.source&apos;, version(&apos;5.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.base&apos;, version(&apos;4.3.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language.ui&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.annotation&apos;, version(&apos;1.1.500.v20200407-1355&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.annotation&apos;, version(&apos;2.2.600.v20200408-1511&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.ide.common&apos;, version(&apos;2.23.0.v20200831-0856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ocl.source&apos;, version(&apos;1.4.0.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.purexbase.source&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk.scheduler&apos;, version(&apos;1.4.800.v20200731-1005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.predicates&apos;, version(&apos;1.12.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.doc.feature.jar&apos;, version(&apos;3.14.400.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.editor&apos;, version(&apos;2.11.0.v20180706-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.runtime.source&apos;, version(&apos;3.19.0.v20200724-1004&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.feature.feature.jar&apos;, version(&apos;1.5.701.v20201027-0550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.ui&apos;, version(&apos;1.4.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.activities&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.ui.interpreter&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.pluggable.core.source&apos;, version(&apos;1.2.500.v20200322-1447&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.edit.feature.group&apos;, version(&apos;1.7.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui&apos;, version(&apos;2.6.100.v20200731-1005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui.feature.jar&apos;, version(&apos;2.17.0.v20190507-0402&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.drivers.emf4atl.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui.feature.jar&apos;, version(&apos;2.19.0.v20200205-0529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.feature.jar&apos;, version(&apos;1.6.700.v20200813-0739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ui&apos;, version(&apos;2.10.0.v20181104-0733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.ecore.converter.feature.group&apos;, version(&apos;2.12.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.edit&apos;, version(&apos;4.7.400.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.base&apos;, version(&apos;1.14.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui.templates&apos;, version(&apos;3.7.0.v20200812-1812&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.lib.macro.source&apos;, version(&apos;2.23.0.v20200831-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.browser&apos;, version(&apos;3.6.900.v20200807-1330&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.doc.feature.jar&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.examples.runtime.diagram.logic.model.edit&apos;, version(&apos;1.2.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator.manipulator.source&apos;, version(&apos;2.1.500.v20200211-1505&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.testing&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.ui.testing.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di&apos;, version(&apos;1.7.600.v20200428-0912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.source.feature.group&apos;, version(&apos;2.21.0.v20200708-0547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.feature.group&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.generator.source&apos;, version(&apos;2.23.0.v20200831-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.ocl.feature.group&apos;, version(&apos;1.12.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.sdk.feature.jar&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.docs.feature.group&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench3.source&apos;, version(&apos;0.15.400.v20191216-0805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.sdk.feature.group&apos;, version(&apos;1.12.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient45&apos;, version(&apos;1.0.301.v20201025-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.console&apos;, version(&apos;1.4.200.v20200828-1034&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.emfvm&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.edit&apos;, version(&apos;1.14.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.resources.win32.x86_64&apos;, version(&apos;3.5.400.v20190812-0909&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.mapping.editor.feature.group&apos;, version(&apos;2.13.0.v20190323-1100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.codegen&apos;, version(&apos;2.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.feature.jar&apos;, version(&apos;2.23.0.v20200701-0840&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.feature.group&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query&apos;, version(&apos;1.7.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.ide.ui.source.feature.jar&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.examples.feature.feature.group&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.debug&apos;, version(&apos;3.16.0.v20200828-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.xml&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.trace.source&apos;, version(&apos;1.1.800.v20200106-1301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.interpreter&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.shared.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services&apos;, version(&apos;1.9.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.io.source&apos;, version(&apos;2.6.0.v20190123-2029&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.core&apos;, version(&apos;2.23.0.v20200831-0856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.log&apos;, version(&apos;1.2.1200.v20200828-0938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.transport.ecf.source&apos;, version(&apos;1.2.400.v20200123-2221&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.core&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.doc.feature.group&apos;, version(&apos;2.19.0.v20200630-0517&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.doc.feature.group&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools.tabbedproperties.source&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.servlet.source&apos;, version(&apos;1.6.600.v20200707-1543&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.suite.api&apos;, version(&apos;1.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench&apos;, version(&apos;3.120.0.v20200829-1411&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.swt.source&apos;, version(&apos;0.14.1100.v20200619-0644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui.source&apos;, version(&apos;3.12.0.v20200824-1258&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper.registry.source&apos;, version(&apos;1.1.400.v20200422-1833&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.editor.source.feature.jar&apos;, version(&apos;2.13.0.v20190323-1100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.annotation.source&apos;, version(&apos;1.1.500.v20200407-1355&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.annotation.source&apos;, version(&apos;2.2.600.v20200408-1511&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.ocl.feature.jar&apos;, version(&apos;1.12.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.editor&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.annotations&apos;, version(&apos;1.2.0.v20200813-0526&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launch.ui.source&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.dsl.additional.builder.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.core.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.specifier.feature.jar&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.uml.feature.jar&apos;, version(&apos;5.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.sdk.feature.group&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.sdk.feature.jar&apos;, version(&apos;2.23.0.v20200822-0801&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.core&apos;, version(&apos;1.17.0.v20200820-0414&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.properties.source&apos;, version(&apos;1.8.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.ui.feature.group&apos;, version(&apos;2.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.model&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.doc.feature.jar&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.engine.emfvm.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.doc&apos;, version(&apos;1.3.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.compare.feature.group&apos;, version(&apos;4.5.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.feature.jar&apos;, version(&apos;2.16.0.v20190920-0401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.printing.win32&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.event.source&apos;, version(&apos;1.5.500.v20200616-0800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.doc&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit&apos;, version(&apos;2.13.0.v20190822-1451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;a.jre.javase&apos;, version(&apos;16.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.ui.source&apos;, version(&apos;1.3.1000.v20200610-0847&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.jetty.source&apos;, version(&apos;3.7.400.v20200123-1333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.doc.feature.jar&apos;, version(&apos;1.12.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.source.feature.group&apos;, version(&apos;2.16.0.v20190920-0401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.source&apos;, version(&apos;2.18.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.feature.group&apos;, version(&apos;2.13.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.io&apos;, version(&apos;9.4.31.v20200723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.feature.group&apos;, version(&apos;3.14.400.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.completeocl.ui&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d&apos;, version(&apos;3.10.100.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language.ui.source&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.emf.validation.validity&apos;, version(&apos;2.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.examples.feature.jar&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.parser&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.trace&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xml.serializer&apos;, version(&apos;2.7.1.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.el&apos;, version(&apos;2.2.0.v201303151357&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo&apos;, version(&apos;4.11.0.v20200902-0811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform_root&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.acceleo.mtl.ide&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.all.sdk.feature.jar&apos;, version(&apos;5.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.source&apos;, version(&apos;3.11.900.v20200828-0853&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emfforms.localization&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.ant&apos;, version(&apos;1.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.acceleo.mtl&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.db.feature.jar&apos;, version(&apos;4.11.0.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.feature.group&apos;, version(&apos;2.20.0.v20200822-0801&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.feature.group&apos;, version(&apos;1.18.0.v20200901-1012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.lib.macro&apos;, version(&apos;2.23.0.v20200831-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.di.source&apos;, version(&apos;1.2.800.v20200128-0855&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.feature.jar&apos;, version(&apos;1.12.2.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna.platform&apos;, version(&apos;4.5.1.v20190425-1842&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.inject&apos;, version(&apos;1.0.0.v20091030&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.ui.source&apos;, version(&apos;3.21.200.v20200828-0853&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.feature.jar&apos;, version(&apos;3.10.100.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.sdk.source.feature.jar&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.source.feature.jar&apos;, version(&apos;3.18.500.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.source.feature.jar&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.util&apos;, version(&apos;9.4.31.v20200723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.feature.jar&apos;, version(&apos;1.17.0.v20200820-0414&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.geoshapes.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.debug.vm&apos;, version(&apos;2.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.core.emf&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.importexport.source&apos;, version(&apos;1.2.500.v20200731-1005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.feature.source.feature.group&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.dnd.ide.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.core.source&apos;, version(&apos;2.23.0.v20200831-0856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.providers.ide.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.editors.source&apos;, version(&apos;3.13.300.v20200812-2334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.examples.runtime.feature.jar&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.renderers.swt.source&apos;, version(&apos;0.14.1300.v20200829-1411&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.servlet.jsp.source&apos;, version(&apos;2.2.0.v201112011158&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.doc.feature.jar&apos;, version(&apos;2.22.0.v20200630-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit.source&apos;, version(&apos;2.13.0.v20190822-1451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools.design.feature.group&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.launcher.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.pivot.uml&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.examples.feature.source.feature.group&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ui.ide.source&apos;, version(&apos;1.3.0.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.examples.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util.gui.source&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.editor&apos;, version(&apos;2.17.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.ui.source&apos;, version(&apos;1.2.0.v20200813-0523&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.core&apos;, version(&apos;3.16.0.v20200828-0817&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.ext.widgets.reference&apos;, version(&apos;2.1.5.202008270808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.hamcrest.core&apos;, version(&apos;1.3.0.v20180420-1519&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.debug.ui&apos;, version(&apos;2.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.contenttype&apos;, version(&apos;3.7.800.v20200724-0804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.ui&apos;, version(&apos;3.14.600.v20200828-0817&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help&apos;, version(&apos;3.8.800.v20200525-0755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.engine.vm&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.examples.feature.group&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;1.3.600.v20200721-1308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.unified.ui.feature.jar&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.specifier.feature.group&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.source&apos;, version(&apos;1.5.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.engine&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.draw2d&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.commands.core.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language.ide&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.doc.user&apos;, version(&apos;3.14.900.v20200902-1022&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.exportmodel.editor.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.source&apos;, version(&apos;1.9.1.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer&apos;, version(&apos;2.12.0.v20190321-1539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.di&apos;, version(&apos;1.2.800.v20200128-0855&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.ssl.source&apos;, version(&apos;1.0.200.v20200611-1836&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.ssl.source&apos;, version(&apos;1.2.400.v20200611-2220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;4.17.0.I20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ui&apos;, version(&apos;2.22.0.v20200424-0451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.feature.jar&apos;, version(&apos;3.14.500.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.sdk.feature.jar&apos;, version(&apos;1.12.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.source.feature.group&apos;, version(&apos;1.12.2.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.urischeme&apos;, version(&apos;1.1.100.v20200729-2048&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.util.feature.group&apos;, version(&apos;4.11.0.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.ssl.feature.feature.jar&apos;, version(&apos;1.1.400.v20200812-2314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.feature.feature.group&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.feature.group&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper&apos;, version(&apos;1.1.500.v20200422-1833&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.example.installer&apos;, version(&apos;1.4.0.v20180706-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.transcoder&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui&apos;, version(&apos;3.12.0.v20200824-1258&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf&apos;, version(&apos;3.9.101.v20201027-0547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper.registry&apos;, version(&apos;1.1.400.v20200422-1833&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.launching.source&apos;, version(&apos;3.9.0.v20200812-1037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclient45.feature.feature.group&apos;, version(&apos;1.0.702.v20201025-2303&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.feature.jar&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools.source&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.concurrent&apos;, version(&apos;1.1.500.v20200106-1437&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.examples.installer&apos;, version(&apos;4.2.2.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.properties.ext.widgets.reference&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools.design.ui&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.feature.jar&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.acceleo.aql.ide&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.text.source&apos;, version(&apos;3.16.400.v20200807-0831&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui.source.feature.jar&apos;, version(&apos;2.17.0.v20190507-0402&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.source.feature.group&apos;, version(&apos;2.19.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.source.feature.group&apos;, version(&apos;3.11.0.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.exportmodel&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.jupiter.api&apos;, version(&apos;5.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.feature.group&apos;, version(&apos;2.16.0.v20190920-0401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide.source&apos;, version(&apos;3.17.200.v20200808-0622&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.debug&apos;, version(&apos;2.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.feature.group&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.traceability&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.ide.ui.ext.widgets.reference&apos;, version(&apos;2.1.5.202008270808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.common&apos;, version(&apos;2.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ui.feature.jar&apos;, version(&apos;2.22.0.v20200424-0451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk.source&apos;, version(&apos;1.1.700.v20200731-1005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.source&apos;, version(&apos;1.9.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.source&apos;, version(&apos;1.5.1.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.wizards&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef&apos;, version(&apos;2.1.5.202008270808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.ui.source&apos;, version(&apos;3.7.900.v20200724-1008&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.exportmodel.editor&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.epp.feature.jar&apos;, version(&apos;4.11.0.v20200902-0811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.logging.source&apos;, version(&apos;1.2.15.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.ecore.exporter&apos;, version(&apos;3.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.profiler.editor&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.dom.source&apos;, version(&apos;1.6.1.v201505192100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.xsd2ecore.editor.source&apos;, version(&apos;2.9.0.v20181105-0510&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.table.ui.ext&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.ocl&apos;, version(&apos;2.0.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.oclinecore.ui&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.server.source&apos;, version(&apos;9.4.31.v20200723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.feature.jar&apos;, version(&apos;1.7.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.m2e&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.runtime&apos;, version(&apos;3.5.300.v20200720-0748&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpclient&apos;, version(&apos;4.5.10.v20200830-2311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.m2e&apos;, version(&apos;2.23.0.v20200831-0856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools.design.properties.source&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.log.source&apos;, version(&apos;1.2.1200.v20200828-0938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.win32.win32.x86_64.source&apos;, version(&apos;3.115.0.v20200831-1002&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit&apos;, version(&apos;3.11.900.v20200828-0853&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emfforms.swt.core&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.source.feature.jar&apos;, version(&apos;2.13.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.graph.feature.jar&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.source.feature.jar&apos;, version(&apos;2.23.0.v20200822-0801&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director.app.source&apos;, version(&apos;1.1.600.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.redist.feature.jar&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.source.feature.group&apos;, version(&apos;2.12.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.eclipse&apos;, version(&apos;2.2.700.v20200813-0739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.dsl.feature.source.feature.group&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.properties.tabbed&apos;, version(&apos;3.8.1000.v20200609-0849&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.el.source&apos;, version(&apos;2.2.0.v201303151357&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.codec.source&apos;, version(&apos;1.14.0.v20200818-1422&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.editor.feature.group&apos;, version(&apos;2.14.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xml.resolver&apos;, version(&apos;1.2.0.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.beans&apos;, version(&apos;1.7.0.v20200717-1533&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.standalone.source&apos;, version(&apos;2.23.0.v20200831-0856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.jreinfo.win32.x86_64&apos;, version(&apos;1.7.0.v20191107-1011&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.ui.refactoring&apos;, version(&apos;3.11.100.v20200817-1715&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ecore.source&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui.source.feature.group&apos;, version(&apos;2.19.0.v20200205-0529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.sdk&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.doc.feature.jar&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.buildship&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.lib.feature.group&apos;, version(&apos;2.23.0.v20200831-0726&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.core.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.unified.core.feature.group&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.feature.group&apos;, version(&apos;2.12.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.editor.source.feature.group&apos;, version(&apos;2.14.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net.win32.x86_64&apos;, version(&apos;1.1.500.v20190925-1337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.source&apos;, version(&apos;2.12.0.v20181104-0733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.ui.source&apos;, version(&apos;2.23.0.v20200703-0737&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.core&apos;, version(&apos;3.14.0.v20200817-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.dsl.ide&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.sdk.feature.jar&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.vm&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analyzers-smartcn&apos;, version(&apos;8.4.1.v20200122-1459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.sdk.feature.group&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.genericeditor.extension.source&apos;, version(&apos;1.1.0.v20200828-0858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common&apos;, version(&apos;2.20.0.v20200822-0801&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.feature.group&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.feature.group&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench.texteditor.source&apos;, version(&apos;3.15.0.v20200812-2334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.contexts&apos;, version(&apos;1.8.400.v20191217-1710&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher&apos;, version(&apos;1.5.400.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.services&apos;, version(&apos;3.9.0.v20200511-1725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.commands&apos;, version(&apos;0.12.900.v20200110-1732&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extensionlocation.source&apos;, version(&apos;1.3.400.v20191213-1911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.compare&apos;, version(&apos;4.4.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tools.layout.spy&apos;, version(&apos;1.0.600.v20200608-0818&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.browser.chromium.win32.win32.x86_64.source&apos;, version(&apos;3.115.0.v20200831-1002&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ide.source&apos;, version(&apos;2.23.0.v20200831-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.examples.runtime.ui.pde&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.table.ui&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.p2.edit&apos;, version(&apos;1.13.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.source.feature.jar&apos;, version(&apos;1.7.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecp.view.util.swt&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ui.source&apos;, version(&apos;2.22.0.v20200424-0451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.doc.feature.jar&apos;, version(&apos;4.3.1.v20200330-1311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.cdo.common&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.junit4.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.edit.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher.win32.win32.x86_64&apos;, version(&apos;1.1.1300.v20200819-0940&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.el&apos;, version(&apos;2.2.0.v201303151357&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.ssl.feature.source.feature.jar&apos;, version(&apos;1.1.500.v20200812-2314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.classic&apos;, version(&apos;5.7.500.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.diagram.ide.ui&apos;, version(&apos;3.4.3.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.cheatsheets.source&apos;, version(&apos;3.7.0.v20200805-2057&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository.tools.source&apos;, version(&apos;2.2.500.v20200110-2121&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.classic.feature.jar&apos;, version(&apos;5.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.emf.xpath&apos;, version(&apos;0.2.800.v20200609-0849&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide.application&apos;, version(&apos;1.3.800.v20200713-0938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher&apos;, version(&apos;1.5.800.v20200727-1323&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.query&apos;, version(&apos;7.0.0.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.doc.feature.group&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.thirdparty.feature.group&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.ui&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.builder.standalone.source&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.user.ui.feature.group&apos;, version(&apos;2.4.900.v20200828-0839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.ecore.converter.feature.jar&apos;, version(&apos;2.12.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui.source&apos;, version(&apos;2.18.0.v20200205-0529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.ocl.source.feature.group&apos;, version(&apos;1.12.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.source&apos;, version(&apos;1.2.0.v20200813-0522&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.h2&apos;, version(&apos;1.3.168.v201212121212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.runtime.source&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.servlet.jsp&apos;, version(&apos;2.2.0.v201112011158&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.base&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.cdo.common.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.tree&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.feature.jar&apos;, version(&apos;2.19.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.core.source&apos;, version(&apos;3.8.1100.v20200806-0621&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.services&apos;, version(&apos;1.3.700.v20190930-1643&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launch&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.databinding.source&apos;, version(&apos;1.12.0.v20200717-1533&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.feature.group&apos;, version(&apos;6.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.win32.source&apos;, version(&apos;1.2.800.v20200127-1343&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.core&apos;, version(&apos;1.18.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.feature.jar&apos;, version(&apos;2.23.0.v20200630-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.core.source&apos;, version(&apos;3.10.800.v20200817-1957&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.annotation.source&apos;, version(&apos;1.3.5.v20200504-1837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.feature.jar&apos;, version(&apos;2.21.0.v20200708-0547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.source&apos;, version(&apos;3.8.800.v20200525-0755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.exporter&apos;, version(&apos;2.10.0.v20190321-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.source&apos;, version(&apos;2.12.0.v20190321-1539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.core&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.ext.awt.source&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.ide.ui.source&apos;, version(&apos;4.4.3.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.inject&apos;, version(&apos;3.0.0.v201605172100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.common.ui&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.net4j&apos;, version(&apos;4.3.1.v20200825-1015&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecp.view.context&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.identity&apos;, version(&apos;3.9.401.v20201027-0550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository.source&apos;, version(&apos;2.4.800.v20200813-0739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.mapping.feature.group&apos;, version(&apos;2.13.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.dsl.feature.source.feature.jar&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.ecore.importer&apos;, version(&apos;2.9.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.edit&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.core&apos;, version(&apos;1.2.0.v20200813-0518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.lib.feature.jar&apos;, version(&apos;2.23.0.v20200831-0726&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.pivot.ui&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.ui.source&apos;, version(&apos;1.2.0.v20200813-0954&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient45.win32.source&apos;, version(&apos;1.0.300.v20200816-1842&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.monitoring&apos;, version(&apos;1.1.800.v20200820-1401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.sdk.feature.jar&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.resources&apos;, version(&apos;3.13.800.v20200706-2152&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.source.feature.group&apos;, version(&apos;3.10.100.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.user.ui.source.feature.group&apos;, version(&apos;2.4.900.v20200828-0839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filebuffers.source&apos;, version(&apos;3.6.1000.v20200409-1035&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.app&apos;, version(&apos;1.5.0.v20200717-0620&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf.edit&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.ide.ui&apos;, version(&apos;2.1.5.202008270808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.common&apos;, version(&apos;1.8.500.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.testing.source&apos;, version(&apos;2.23.0.v20200831-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.providers.ide&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.source.feature.jar&apos;, version(&apos;2.21.0.v20200708-0547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf.ui&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.providers&apos;, version(&apos;1.7.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.ide.ui.feature.jar&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.source&apos;, version(&apos;2.6.100.v20200731-1005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore&apos;, version(&apos;2.23.0.v20200630-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.uml&apos;, version(&apos;5.10.100.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.lib&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf.tx&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.edit.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.ui.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator.source&apos;, version(&apos;3.9.400.v20200723-2304&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.xml.source&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.explorer.ui&apos;, version(&apos;4.6.1.v20200902-0810&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.trace.editor.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.example.installer&apos;, version(&apos;1.10.0.v20200518-1440&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.jreinfo&apos;, version(&apos;1.14.0.v20200901-1012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.cheatsheets&apos;, version(&apos;3.7.0.v20200805-2057&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.ecore&apos;, version(&apos;3.15.100.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.compiler&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.source&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.generator&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.jcraft.jsch&apos;, version(&apos;0.1.55.v20190404-1902&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.doc&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.gmf.notation&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.mapping.editor.source.feature.jar&apos;, version(&apos;2.13.0.v20190323-1100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt&apos;, version(&apos;0.13.1100.v20200819-0632&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.server.feature.group&apos;, version(&apos;4.11.0.v20200902-0811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.smap&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.server.product&apos;, version(&apos;4.2.1.v20200411-0357&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.all.feature.group&apos;, version(&apos;5.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.edit&apos;, version(&apos;4.5.2.v20200615-1414&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.editor.diagram&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.actions&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.testing&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.common&apos;, version(&apos;2.1.5.202008270808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.server.security&apos;, version(&apos;4.5.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.doc.user&apos;, version(&apos;3.15.800.v20200828-1432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.source.feature.jar&apos;, version(&apos;2.19.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.doc&apos;, version(&apos;3.14.400.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.cdo.feature.feature.jar&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatechecker.source&apos;, version(&apos;1.2.300.v20200222-1600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.edit&apos;, version(&apos;1.6.0.v20190323-1031&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.ide.ui.properties&apos;, version(&apos;2.1.5.202008270808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.smap.source&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.tools.jdt.templates&apos;, version(&apos;4.8.400.v20191115-2149&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.sdk&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.rcp.feature.feature.group&apos;, version(&apos;1.4.900.v20200813-0739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.themes.source&apos;, version(&apos;1.2.1100.v20200825-0757&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.source.feature.jar&apos;, version(&apos;3.10.100.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.source.feature.jar&apos;, version(&apos;2.3.300.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.constants&apos;, version(&apos;1.13.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tools.layout.spy.source&apos;, version(&apos;1.0.600.v20200608-0818&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.jarprocessor&apos;, version(&apos;1.1.600.v20200217-1130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ocl.feature.group&apos;, version(&apos;1.12.2.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.launching.source&apos;, version(&apos;3.18.0.v20200824-1854&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.feature.feature.jar&apos;, version(&apos;3.14.1702.v20201025-2315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui.source&apos;, version(&apos;1.9.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.views.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.common&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.property&apos;, version(&apos;1.8.100.v20200619-0651&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.converter.source&apos;, version(&apos;2.10.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.examples.runtime.diagram.logic.model.editor&apos;, version(&apos;1.2.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.preferences&apos;, version(&apos;3.8.0.v20200422-1833&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.printing.win32.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.feature.group&apos;, version(&apos;3.18.500.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.ui&apos;, version(&apos;4.2.0.v20200724-0708&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.source.feature.group&apos;, version(&apos;2.20.0.v20200822-0801&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.core.ui.vm.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.buildship.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.jupiter.params&apos;, version(&apos;5.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.observable.source&apos;, version(&apos;1.10.0.v20200730-0848&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director.source&apos;, version(&apos;2.4.700.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.util&apos;, version(&apos;3.12.0.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui.feature.group&apos;, version(&apos;2.19.0.v20200205-0529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.generator.common.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpclient.win&apos;, version(&apos;4.5.10.v20200830-2311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.http.source&apos;, version(&apos;9.4.31.v20200723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.trace.edit&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.xtext.idioms.ui&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.core&apos;, version(&apos;1.3.900.v20200422-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.reconciler.dropins.source&apos;, version(&apos;1.3.400.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.core.sdk.feature.jar&apos;, version(&apos;5.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.ide.ui.feature.group&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.feature.jar&apos;, version(&apos;2.23.0.v20200822-0801&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.server.ocl&apos;, version(&apos;4.3.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.edit&apos;, version(&apos;1.15.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launcher.feature.jar&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.geoshapes&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.source.feature.group&apos;, version(&apos;2.23.0.v20200822-0801&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools.design.feature.jar&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.security&apos;, version(&apos;4.4.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds1_2.lib.source&apos;, version(&apos;1.0.400.v20191119-0943&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.m2e.source&apos;, version(&apos;2.23.0.v20200831-0856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.ide.ui.feature.group&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.source&apos;, version(&apos;2.20.0.v20200822-0801&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide.application.source&apos;, version(&apos;1.3.800.v20200713-0938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecp.view.template.service&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.unified.feature.jar&apos;, version(&apos;4.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.ui.source&apos;, version(&apos;1.2.0.v20200813-0519&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.tree.ui&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.feature.group&apos;, version(&apos;3.10.100.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.ext&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.security.edit&apos;, version(&apos;4.5.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emfforms.core.services.emf&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.sdk.feature.group&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.services.source&apos;, version(&apos;2.2.400.v20200622-1247&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.feature.feature.jar&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.editor.source&apos;, version(&apos;2.11.0.v20180706-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository&apos;, version(&apos;2.4.800.v20200813-0739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.compiler.tool.source&apos;, version(&apos;1.2.1000.v20200828-0941&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.base.ui&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.core&apos;, version(&apos;3.6.700.v20200828-0941&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.ui.admin&apos;, version(&apos;4.2.1.v20200330-1311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.doc&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.properties&apos;, version(&apos;1.9.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.expressions.source&apos;, version(&apos;3.7.0.v20200720-1126&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.externaltools.source&apos;, version(&apos;1.1.700.v20200416-1310&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.dsl.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem.win32.x86_64&apos;, version(&apos;1.4.200.v20190812-0909&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.ui&apos;, version(&apos;3.6.500.v20200828-1336&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup&apos;, version(&apos;1.18.0.v20200820-0414&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.command.source&apos;, version(&apos;1.0.2.v20170914-1324&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.compatibility.ui&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.diagram.sirius.source&apos;, version(&apos;1.1.0.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.ui.ext&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.source&apos;, version(&apos;8.0.1.v20200420-1007&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util.source&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util.source&apos;, version(&apos;1.13.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.modeling.feature.feature.jar&apos;, version(&apos;4.17.0.20200910-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.editor.feature.group&apos;, version(&apos;2.13.0.v20190323-1100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.ide&apos;, version(&apos;3.15.100.v20200323-2111&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.core&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.ssl&apos;, version(&apos;1.0.200.v20200611-1836&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.source.feature.jar&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.feature.group&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.resources.editor.ide&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extras.feature.feature.group&apos;, version(&apos;1.4.900.v20200828-0839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.opentest4j&apos;, version(&apos;1.2.0.v20190826-0900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;epp.package.modeling&apos;, version(&apos;4.17.0.20200910-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin&apos;, version(&apos;2.1.400.v20191002-0702&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.core.source&apos;, version(&apos;3.6.900.v20200412-2017&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.examples&apos;, version(&apos;1.2.100.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf&apos;, version(&apos;2.8.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.source.feature.jar&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.ide.executable.win32.win32.x86_64&apos;, version(&apos;4.17.0.I20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk&apos;, version(&apos;1.1.700.v20200731-1005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.shell.source&apos;, version(&apos;1.1.0.v20180713-1646&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.cdo.feature.source.feature.group&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.converter.source.feature.jar&apos;, version(&apos;2.15.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ui.ide&apos;, version(&apos;1.3.0.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.profiler.edit&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit.source.feature.jar&apos;, version(&apos;2.14.0.v20190822-1451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.feature.jar&apos;, version(&apos;1.12.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.core.runtime&apos;, version(&apos;4.17.0.I20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.swt&apos;, version(&apos;0.14.1100.v20200619-0644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata.repository&apos;, version(&apos;1.3.400.v20191211-1528&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.observable&apos;, version(&apos;1.10.0.v20200730-0848&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.cdo&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.rcp.feature.source.feature.jar&apos;, version(&apos;1.4.900.v20200813-0739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.svggen&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.feature.jar&apos;, version(&apos;2.12.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analyzers-common&apos;, version(&apos;8.4.1.v20200122-1459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.doc.feature.jar&apos;, version(&apos;2.19.0.v20200630-0517&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net.source&apos;, version(&apos;1.3.1000.v20200715-0827&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.sdk.feature.jar&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.actions.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sdk.feature.jar&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.bridge&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp_root&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.source&apos;, version(&apos;2.23.0.v20200831-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.adt.ui.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.extractor.lib&apos;, version(&apos;1.8.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.db.h2.feature.group&apos;, version(&apos;4.4.0.v20200412-0425&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2xml&apos;, version(&apos;2.11.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.source.feature.jar&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.gef&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.graph.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.engine.source&apos;, version(&apos;2.6.700.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.diagram.ide.ui.sirius&apos;, version(&apos;1.1.1.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.codegen.ecore.ui.feature.jar&apos;, version(&apos;2.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.ssl.feature.feature.group&apos;, version(&apos;1.1.500.v20200812-2314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.configuration&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.adt&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.tree.ui.ext&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.source.feature.group&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ui.source.feature.jar&apos;, version(&apos;2.22.0.v20200424-0451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.defaultrules&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.modeling.feature.feature.group&apos;, version(&apos;4.17.0.20200910-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.expressions&apos;, version(&apos;3.7.0.v20200720-1126&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.feature.group&apos;, version(&apos;1.12.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.jetty&apos;, version(&apos;3.7.400.v20200123-1333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.rcp.feature.source.feature.group&apos;, version(&apos;1.4.900.v20200813-0739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.cheatsheets&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.swt&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.feature.jar&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.doc&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.junit4.feature.source.feature.group&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.examples.feature.feature.jar&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecp.edit&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.printing.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.dsls.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.standalone&apos;, version(&apos;2.7.200.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit.source.feature.group&apos;, version(&apos;2.14.0.v20190822-1451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.wizard.source&apos;, version(&apos;2.23.0.v20200831-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe.utils&apos;, version(&apos;1.5.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.source&apos;, version(&apos;3.5.1100.v20200828-0803&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.dsl.feature.feature.group&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.transfer.ui&apos;, version(&apos;4.3.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.sdk.feature.group&apos;, version(&apos;3.10.100.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingepp.package.modeling.ini.win32.win32.x86_64&apos;, version(&apos;4.17.0.20200910-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.ui&apos;, version(&apos;1.2.0.v20200813-0954&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.xml&apos;, version(&apos;1.3.4.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.markup.ui&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.activities.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.feature.jar&apos;, version(&apos;3.11.0.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext&apos;, version(&apos;2.23.0.v20200831-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.eclipse.source&apos;, version(&apos;2.2.700.v20200813-0739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.feature.group&apos;, version(&apos;1.17.0.v20200820-0414&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2xml.ui.source&apos;, version(&apos;2.12.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emfforms.core.bazaar&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.ssl.feature.source.feature.group&apos;, version(&apos;1.1.500.v20200812-2314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.common&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecp.view.model.common.di&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.drivers.emf4atl&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.rcp&apos;, version(&apos;2.5.2.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare&apos;, version(&apos;3.5.3.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.source.feature.jar&apos;, version(&apos;1.12.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.oclstdlib.ui&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.io.source&apos;, version(&apos;9.4.31.v20200723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.feature.group&apos;, version(&apos;1.6.700.v20200813-0739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.properties.ui&apos;, version(&apos;2.1.5.202008270808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.feature.group&apos;, version(&apos;1.7.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.editor&apos;, version(&apos;2.8.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.debug.source&apos;, version(&apos;3.16.0.v20200828-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.themes&apos;, version(&apos;1.2.1100.v20200825-0757&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.sdk.feature.group&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analyzers-smartcn.source&apos;, version(&apos;8.4.1.v20200122-1459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.ext.widgets.reference&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.ui&apos;, version(&apos;1.3.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.feature.jar&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.ui&apos;, version(&apos;3.8.1000.v20200806-0621&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.sdk.feature.group&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions.supplier&apos;, version(&apos;0.15.700.v20200622-1247&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.server.net4j&apos;, version(&apos;4.2.1.v20200825-1015&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.sdk.feature.group&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.registry&apos;, version(&apos;3.9.0.v20200625-1425&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.edit&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.unified&apos;, version(&apos;4.7.400.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient45.source&apos;, version(&apos;1.0.301.v20201025-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools.design.source&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin.equinox&apos;, version(&apos;1.1.400.v20200319-1546&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.feature.feature.group&apos;, version(&apos;1.5.701.v20201027-0550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.xtext.idioms&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.expressions.edit&apos;, version(&apos;4.4.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.ide.source&apos;, version(&apos;3.4.3.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extensionlocation&apos;, version(&apos;1.3.400.v20191213-1911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui&apos;, version(&apos;2.18.0.v20190507-0402&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.lib.source&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.editor.properties.ext.widgets.reference&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient45.win32&apos;, version(&apos;1.0.300.v20200816-1842&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.diagram.gmf.feature.group&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.ui.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.source.feature.jar&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.artifact.repository.source&apos;, version(&apos;1.3.500.v20200406-2025&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.bindings.source&apos;, version(&apos;0.12.900.v20200513-0930&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.jasper.glassfish&apos;, version(&apos;2.2.2.v201501141630&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.feature.jar&apos;, version(&apos;2.13.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.manipulation&apos;, version(&apos;1.14.100.v20200817-2001&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.common.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.tools.emf.editor3x&apos;, version(&apos;4.7.600.v20200723-1429&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.ui&apos;, version(&apos;1.14.0.v20200805-0908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools.design_root&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.common&apos;, version(&apos;3.13.0.v20200828-1034&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ide.source&apos;, version(&apos;2.23.0.v20200831-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.core.ui.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.feature.source.feature.jar&apos;, version(&apos;1.5.701.v20201027-0550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.source&apos;, version(&apos;1.8.0.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.feature.jar&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.continuation&apos;, version(&apos;9.4.31.v20200723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation&apos;, version(&apos;1.10.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.diagram.sirius.source.feature.jar&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.beans.source&apos;, version(&apos;1.7.0.v20200717-1533&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.action&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.core.source&apos;, version(&apos;1.3.900.v20200422-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.sync&apos;, version(&apos;1.13.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ocl.source.feature.group&apos;, version(&apos;1.12.2.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.core&apos;, version(&apos;3.10.800.v20200817-1957&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.commons&apos;, version(&apos;1.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.annotations.source&apos;, version(&apos;1.2.0.v20200813-0526&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.win32.source&apos;, version(&apos;3.4.400.v20200414-1247&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.externaltools&apos;, version(&apos;3.4.800.v20200612-0848&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.all.feature.jar&apos;, version(&apos;5.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.core.source&apos;, version(&apos;1.2.0.v20200813-0518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.manipulation.source&apos;, version(&apos;1.14.100.v20200817-2001&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.commands.source&apos;, version(&apos;3.9.700.v20191217-1850&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.redist.feature.group&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.doc.isv&apos;, version(&apos;3.10.100.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.resources.source&apos;, version(&apos;3.13.800.v20200706-2152&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.source&apos;, version(&apos;1.7.600.v20200428-0912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.ibm.icu&apos;, version(&apos;67.1.0.v20200706-1749&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.annotations&apos;, version(&apos;1.1.400.v20190929-1236&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.common.feature.jar&apos;, version(&apos;2.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecp.view.template.model&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui.render.awt&apos;, version(&apos;1.8.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.widgets&apos;, version(&apos;1.2.700.v20191222-1048&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.mapping&apos;, version(&apos;2.8.0.v20180706-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.doc&apos;, version(&apos;1.3.0.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator.source&apos;, version(&apos;1.3.600.v20200721-1308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.sdk.feature.group&apos;, version(&apos;2.23.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.jxpath&apos;, version(&apos;1.3.0.v200911051830&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.services&apos;, version(&apos;2.2.400.v20200622-1247&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.ui&apos;, version(&apos;1.18.0.v20200805-0908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.ui.feature.jar&apos;, version(&apos;2.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.jvm&apos;, version(&apos;4.2.1.v20200528-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.synchronizer&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.feature.jar&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change.edit&apos;, version(&apos;2.8.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt.source&apos;, version(&apos;0.13.1100.v20200819-0632&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.source&apos;, version(&apos;3.5.3.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.editor&apos;, version(&apos;1.18.0.v20200805-0908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.engine&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.source.feature.group&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools.sdk.feature.group&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt&apos;, version(&apos;3.18.500.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.workingsets&apos;, version(&apos;1.11.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit4.runtime.source&apos;, version(&apos;1.1.1300.v20200720-0748&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui.templates.source&apos;, version(&apos;3.7.0.v20200812-1812&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2xml.ui&apos;, version(&apos;2.12.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.scr.source&apos;, version(&apos;2.1.16.v20200110-1820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.ide.source&apos;, version(&apos;3.15.100.v20200323-2111&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.ecore.edit&apos;, version(&apos;4.6.500.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language.ide.source&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.clipboard.core.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.hamcrest.core.source&apos;, version(&apos;1.3.0.v20180420-1519&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.printing.render&apos;, version(&apos;1.8.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.diagram.sirius.source.feature.group&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.util&apos;, version(&apos;2.23.0.v20200831-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding&apos;, version(&apos;1.10.0.v20200815-1752&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.compatibility.state.source&apos;, version(&apos;1.2.100.v20200811-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.sdk.feature.group&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.diagram.sirius.feature.group&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclient45.feature.source.feature.jar&apos;, version(&apos;1.0.702.v20201025-2303&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.compiler.apt&apos;, version(&apos;1.3.1100.v20200828-0941&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.feature.group&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.examples.runtime.diagram.logic.model&apos;, version(&apos;1.2.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.transcoder.source&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.tree&apos;, version(&apos;8.0.1.v20200420-1007&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.resources.editor&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.servlet&apos;, version(&apos;1.6.600.v20200707-1543&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.edit.source&apos;, version(&apos;1.6.0.v20190323-1031&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launcher.source.feature.group&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text.quicksearch.source&apos;, version(&apos;1.0.300.v20200519-2023&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen&apos;, version(&apos;2.21.0.v20200708-0547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.sdk.feature.jar&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.dsl.additional.builder&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates.ide&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend&apos;, version(&apos;2.2.0.v201605260315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net&apos;, version(&apos;1.3.1000.v20200715-0827&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.ecore&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net.win32.x86_64.source&apos;, version(&apos;1.1.500.v20190925-1337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.dialogs&apos;, version(&apos;1.2.0.v20200807-0944&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.dnd&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper.source&apos;, version(&apos;1.1.500.v20200422-1833&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.editor.sequence&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.source&apos;, version(&apos;2.16.0.v20190920-0401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.edit&apos;, version(&apos;2.11.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.ecore.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.diagram.sirius&apos;, version(&apos;1.1.0.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.ide.source&apos;, version(&apos;2.23.0.v20200831-0856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.feature.source.feature.group&apos;, version(&apos;1.5.701.v20201027-0550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingepp.package.modeling.executable.win32.win32.x86_64&apos;, version(&apos;4.17.0.20200910-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.feature.jar&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.views&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.ui.compare&apos;, version(&apos;4.5.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui.source.feature.jar&apos;, version(&apos;2.19.0.v20200205-0529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.util.feature.jar&apos;, version(&apos;4.11.0.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.testing.source&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.guava&apos;, version(&apos;27.1.0.v20190517-1946&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.types&apos;, version(&apos;2.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.source.feature.jar&apos;, version(&apos;2.16.0.v20190920-0401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emfforms.view.annotation.model&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.common&apos;, version(&apos;4.17.0.20200910-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.junit4&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.exporter.source&apos;, version(&apos;2.10.0.v20190321-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.pb&apos;, version(&apos;2.3.5.v201404071733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sdk.feature.group&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.source&apos;, version(&apos;3.7.1100.v20200611-0145&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecp.view.model.common&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.ide&apos;, version(&apos;3.4.3.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.trace&apos;, version(&apos;1.1.800.v20200106-1301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.feature.group&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit5.runtime.source&apos;, version(&apos;1.0.1000.v20200720-0748&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.shared.jdt38&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.examples&apos;, version(&apos;1.2.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.ui&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.runtime.common.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.examples.feature.source.feature.jar&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ant&apos;, version(&apos;2.11.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cheatsheets&apos;, version(&apos;2.8.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.editor.source.feature.jar&apos;, version(&apos;2.17.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecp.ui.view&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna.platform.source&apos;, version(&apos;4.5.1.v20190425-1842&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.java&apos;, version(&apos;2.11.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.drivers.uml24atl&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator.resources.source&apos;, version(&apos;3.7.400.v20200722-0751&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding&apos;, version(&apos;1.5.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.p2&apos;, version(&apos;1.16.0.v20200814-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ui&apos;, version(&apos;1.7.0.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatesite.source&apos;, version(&apos;1.1.400.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.render&apos;, version(&apos;1.7.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.dsl.ide.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.debug&apos;, version(&apos;3.1.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.feature.group&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.genericeditor.extension&apos;, version(&apos;1.1.0.v20200828-0858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.browser.chromium.win32.win32.x86_64&apos;, version(&apos;3.115.0.v20200831-1002&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.source&apos;, version(&apos;3.16.0.v20200828-0759&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.mapping.editor&apos;, version(&apos;2.9.0.v20180706-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.adt.ui&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.runtime.common&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.source.feature.group&apos;, version(&apos;4.17.0.v20200831-1002&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.edit&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.examples.installer.feature.group&apos;, version(&apos;4.3.1.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.security.editor&apos;, version(&apos;4.3.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.ui.source&apos;, version(&apos;3.8.1000.v20200806-0621&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.properties.source&apos;, version(&apos;1.9.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecp.edit.swt&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.source&apos;, version(&apos;3.11.0.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.scr&apos;, version(&apos;2.1.16.v20200110-1820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.editor.source.feature.group&apos;, version(&apos;2.13.0.v20190323-1100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.debug.core&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.profiler&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.transfer.workspace&apos;, version(&apos;4.3.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.runner&apos;, version(&apos;1.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.runtime.sdk.feature.group&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.ui&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.build.source&apos;, version(&apos;3.10.800.v20200410-1419&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.vm.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.ocl.source.feature.jar&apos;, version(&apos;1.12.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.doc.feature.group&apos;, version(&apos;2.22.0.v20200630-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.common.edit.feature.group&apos;, version(&apos;2.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.editor.feature.jar&apos;, version(&apos;2.14.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.util.ui&apos;, version(&apos;3.8.0.v20200528-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.m2e.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.transfer.repository&apos;, version(&apos;4.3.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.resources.editor.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.console.source&apos;, version(&apos;3.9.300.v20200828-0817&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language.sdk.feature.group&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.util&apos;, version(&apos;1.15.0.v20200711-0605&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.feature.group&apos;, version(&apos;1.12.2.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.dnd.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.db.h2.feature.jar&apos;, version(&apos;4.4.0.v20200412-0425&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.editor.tree&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.contenttype.source&apos;, version(&apos;3.7.800.v20200724-0804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.ibm.icu.source&apos;, version(&apos;67.1.0.v20200706-1749&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.servlet&apos;, version(&apos;3.1.0.v201410161800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.ecore.exporter.source&apos;, version(&apos;2.7.0.v20180706-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.feature.group&apos;, version(&apos;4.11.0.v20200902-0811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui&apos;, version(&apos;1.8.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.xsd2ecore.source&apos;, version(&apos;2.9.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.junit.runtime.source&apos;, version(&apos;3.5.900.v20200810-0835&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.feature.group&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.common.source&apos;, version(&apos;3.13.0.v20200828-1034&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.pluggable.core&apos;, version(&apos;1.2.500.v20200322-1447&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.interpreter&apos;, version(&apos;4.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.source.feature.group&apos;, version(&apos;1.7.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.providers.source&apos;, version(&apos;1.7.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.inject.source&apos;, version(&apos;1.0.0.v20091030&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions.supplier.source&apos;, version(&apos;0.15.700.v20200622-1247&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.dsl.ui.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.impactanalyzer.ui&apos;, version(&apos;3.12.100.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.doc.feature.jar&apos;, version(&apos;1.12.2.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.model.edit&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ui.source.feature.group&apos;, version(&apos;2.22.0.v20200424-0451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.net&apos;, version(&apos;1.3.800.v20200422-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecp.ui.view.swt&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.junit4.feature.feature.jar&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.osgi.bundle.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.examples.feature.jar&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.feature.jar&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.notifications&apos;, version(&apos;0.2.0.v20200810-0826&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.launcher&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.ui&apos;, version(&apos;4.3.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.source&apos;, version(&apos;2.8.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.editor.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.core.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm&apos;, version(&apos;8.0.1.v20200420-1007&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.emf.xpath.source&apos;, version(&apos;0.2.800.v20200609-0849&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.adt.debug&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.feature.group&apos;, version(&apos;5.5.1.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates.ui.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.ui&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.urischeme.source&apos;, version(&apos;1.1.100.v20200729-2048&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.doc&apos;, version(&apos;2.17.0.v20200630-0517&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk.scheduler.source&apos;, version(&apos;1.4.800.v20200731-1005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates.ui&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.jcraft.jsch.source&apos;, version(&apos;0.1.55.v20190404-1902&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.launching.source&apos;, version(&apos;1.2.1000.v20200610-1458&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.transfer&apos;, version(&apos;4.4.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.sequence&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.dom.svg&apos;, version(&apos;1.1.0.v201011041433&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.feature.jar&apos;, version(&apos;2.3.300.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.server.db.feature.jar&apos;, version(&apos;4.9.1.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.ide.configuration&apos;, version(&apos;4.17.0.I20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecp.view.model&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.tukaani.xz.source&apos;, version(&apos;1.8.0.v20180207-1613&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.ant&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.debug.ui.source&apos;, version(&apos;3.12.0.v20200828-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.type.core.source&apos;, version(&apos;1.9.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.engine.vm.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.base&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.dom.svg.source&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.core.source&apos;, version(&apos;3.14.0.v20200817-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools&apos;, version(&apos;1.2.0.v20200813-0522&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.common&apos;, version(&apos;4.17.0.I20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.source&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.update.configurator.source&apos;, version(&apos;3.4.600.v20200422-1910&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingepp.package.modeling.application&apos;, version(&apos;4.17.0.20200910-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.formatterapp&apos;, version(&apos;1.0.0.v20200119-0748&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.edit.source.feature.jar&apos;, version(&apos;2.13.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.feature.group&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.source&apos;, version(&apos;1.10.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.source&apos;, version(&apos;2.6.300.v20200211-1504&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.edit&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sdk&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.unified.core.feature.jar&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.server.feature.jar&apos;, version(&apos;4.11.0.v20200902-0811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.source.feature.group&apos;, version(&apos;3.14.500.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench3&apos;, version(&apos;0.15.400.v20191216-0805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.source.feature.jar&apos;, version(&apos;2.23.0.v20200630-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.lang&apos;, version(&apos;2.6.0.v201404270220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views&apos;, version(&apos;3.10.400.v20200611-1719&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.examples.runtime.ui.pde.feature.group&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.sdk.feature.jar&apos;, version(&apos;1.12.2.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.common.db&apos;, version(&apos;3.1.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.svggen.source&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui&apos;, version(&apos;2.18.0.v20200205-0529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.classic.feature.group&apos;, version(&apos;5.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.ui.feature.jar&apos;, version(&apos;2.23.0.v20200703-0737&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.commons.source&apos;, version(&apos;1.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.notifications.source&apos;, version(&apos;0.2.0.v20200810-0826&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.predicates.edit&apos;, version(&apos;1.11.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.ui.properties&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.ssl.feature.source.feature.group&apos;, version(&apos;1.1.400.v20200812-2314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language.sdk.feature.jar&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpcore.source&apos;, version(&apos;4.4.12.v20200108-1212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.doc.feature.jar&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.editor.feature.jar&apos;, version(&apos;2.17.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.source.feature.jar&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.feature.jar&apos;, version(&apos;4.17.0.v20200831-1002&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.xtext.serializer&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.http&apos;, version(&apos;9.4.31.v20200723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.genericeditor.source&apos;, version(&apos;1.1.800.v20200828-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emfforms.core.services.segments&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.ui.source&apos;, version(&apos;3.14.600.v20200828-0817&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.util.source&apos;, version(&apos;9.4.31.v20200723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.source.feature.group&apos;, version(&apos;2.23.0.v20200630-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.examples&apos;, version(&apos;2.23.0.v20200831-0856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.common.feature.feature.jar&apos;, version(&apos;4.17.0.20200910-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.validation&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.servlet.source&apos;, version(&apos;9.4.31.v20200723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.diagram.ide.ui.sirius.source&apos;, version(&apos;1.1.1.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions.source&apos;, version(&apos;0.16.0.v20200507-0938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.views.common&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.examples&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.opentest4j.source&apos;, version(&apos;1.2.0.v20190826-0900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.ide&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer&apos;, version(&apos;3.2.601.v20201025-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extras.feature.source.feature.group&apos;, version(&apos;1.4.900.v20200828-0839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.markup&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.clipboard.core&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emfforms.common&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.transport.ecf&apos;, version(&apos;1.2.400.v20200123-2221&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.compiler.tool&apos;, version(&apos;1.2.1000.v20200828-0941&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text.source&apos;, version(&apos;3.10.300.v20200807-0831&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui.source.feature.group&apos;, version(&apos;2.17.0.v20190507-0402&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.core.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.feature.source.feature.jar&apos;, version(&apos;3.14.1702.v20201025-2315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.shared.jdt38.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore&apos;, version(&apos;2.8.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.swt.win32&apos;, version(&apos;1.0.700.v20200607-1314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.apache.felix.scr&apos;, version(&apos;4.17.0.I20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui.render&apos;, version(&apos;1.7.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.jasper.glassfish.source&apos;, version(&apos;2.2.2.v201501141630&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.core.feature.jar&apos;, version(&apos;1.18.0.v20200901-1012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.editor.source.feature.group&apos;, version(&apos;2.17.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.ide.config.win32.win32.x86_64&apos;, version(&apos;4.17.0.I20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.security&apos;, version(&apos;9.4.31.v20200723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.compatibility.state&apos;, version(&apos;1.2.100.v20200811-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.ssl.feature.feature.jar&apos;, version(&apos;1.1.500.v20200812-2314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.mapping.editor.feature.jar&apos;, version(&apos;2.13.0.v20190323-1100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.feature.jar&apos;, version(&apos;3.18.500.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.preferences&apos;, version(&apos;1.12.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.console&apos;, version(&apos;1.1.300.v20191014-1219&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core&apos;, version(&apos;3.23.0.v20200828-0941&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.addons.swt.source&apos;, version(&apos;1.3.1100.v20200703-0611&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.engine&apos;, version(&apos;1.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.userstorage.oauth&apos;, version(&apos;1.1.0.v20190307-0457&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.win32&apos;, version(&apos;3.4.400.v20200414-1247&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpclient.win.source&apos;, version(&apos;4.5.10.v20200830-2311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.formatdata&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.forms&apos;, version(&apos;3.10.0.v20200727-0948&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.doc&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.source.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.examples&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.ide&apos;, version(&apos;2.23.0.v20200831-0856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.profile.standard&apos;, version(&apos;1.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xmlgraphics&apos;, version(&apos;2.4.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.ide.source&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.edit.feature.jar&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.drivers.uml24atl.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.core&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl&apos;, version(&apos;3.15.100.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.userstorage.ui&apos;, version(&apos;1.1.0.v20190307-0457&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.ui&apos;, version(&apos;2.23.0.v20200703-0737&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ui.source&apos;, version(&apos;1.7.0.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.junit&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.junit4&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.tree.source&apos;, version(&apos;8.0.1.v20200420-1007&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.ui&apos;, version(&apos;3.7.900.v20200724-1008&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.feature.group&apos;, version(&apos;2.21.0.v20200708-0547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.feature.group&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.dialogs.source&apos;, version(&apos;1.2.0.v20200807-0944&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.ui&apos;, version(&apos;1.2.0.v20200813-0519&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.source.feature.jar&apos;, version(&apos;2.12.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.doc.feature.group&apos;, version(&apos;1.12.2.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.aql.feature.group&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools.design&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates.ide.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.migrator&apos;, version(&apos;3.2.0.v20200825-0917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef&apos;, version(&apos;3.11.0.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.console.source&apos;, version(&apos;1.1.300.v20191014-1219&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.source.feature.group&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.bridge.source&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.editor.feature.jar&apos;, version(&apos;2.13.0.v20190323-1100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.variables&apos;, version(&apos;3.4.800.v20200120-1101&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extras.feature.source.feature.jar&apos;, version(&apos;1.4.900.v20200828-0839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.launching&apos;, version(&apos;3.18.0.v20200824-1854&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace&apos;, version(&apos;1.5.1.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.ui&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.tukaani.xz&apos;, version(&apos;1.8.0.v20180207-1613&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.feature.group&apos;, version(&apos;2.3.300.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.doc.feature.group&apos;, version(&apos;4.3.1.v20200330-1311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.mapping.feature.jar&apos;, version(&apos;2.13.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2ecore.editor.source&apos;, version(&apos;2.10.0.v20181104-0733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.sdk.feature.group&apos;, version(&apos;5.5.1.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.dnd.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator.manipulator&apos;, version(&apos;2.1.500.v20200211-1505&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.examples.runtime.feature.group&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.server.db&apos;, version(&apos;4.9.1.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j&apos;, version(&apos;4.10.1.v20200901-1413&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.browser.source&apos;, version(&apos;3.6.900.v20200807-1330&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.edit.feature.jar&apos;, version(&apos;1.7.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.sequence.edit&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.feature.group&apos;, version(&apos;3.14.500.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.jupiter.migrationsupport.source&apos;, version(&apos;5.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.tools&apos;, version(&apos;4.9.0.v20200923-1123&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.oclstdlib&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.editor&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.source.feature.jar&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.source.feature.group&apos;, version(&apos;2.13.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director.app&apos;, version(&apos;1.1.600.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata&apos;, version(&apos;2.5.0.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository.tools&apos;, version(&apos;2.2.500.v20200110-2121&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.xsd2ecore.editor&apos;, version(&apos;2.9.0.v20181105-0510&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.reconciler.dropins&apos;, version(&apos;1.3.400.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.examples&apos;, version(&apos;1.3.0.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.core.feature.group&apos;, version(&apos;1.18.0.v20200901-1012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.mapping.editor.source&apos;, version(&apos;2.9.0.v20180706-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.lib&apos;, version(&apos;1.1.400.v20191119-0943&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.win32.x86_64.source&apos;, version(&apos;1.1.200.v20190812-0919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.mapping.source&apos;, version(&apos;2.8.0.v20180706-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.edit.feature.jar&apos;, version(&apos;5.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.jupiter.engine&apos;, version(&apos;5.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.win32.win32.x86_64&apos;, version(&apos;3.115.0.v20200831-1002&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.server.db.feature.group&apos;, version(&apos;4.9.1.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.source.feature.group&apos;, version(&apos;2.3.300.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.ecore.exporter&apos;, version(&apos;2.7.0.v20180706-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.core&apos;, version(&apos;3.6.900.v20200412-2017&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.feature.jar&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;epp.package.modeling.executable.win32.win32.x86_64&apos;, version(&apos;4.17.0.20200910-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui.source&apos;, version(&apos;2.18.0.v20190507-0402&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.db&apos;, version(&apos;4.9.0.v20200610-0352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.search&apos;, version(&apos;3.12.0.v20200727-2017&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.sdk.feature.jar&apos;, version(&apos;3.11.0.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.text&apos;, version(&apos;3.16.400.v20200807-0831&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.graph&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.ui.questionnaire&apos;, version(&apos;1.12.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.jobs.source&apos;, version(&apos;3.10.800.v20200421-0950&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apiguardian&apos;, version(&apos;1.1.0.v20190826-0900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.runtime&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.i18n.source&apos;, version(&apos;1.13.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.java&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;epp.package.modeling.executable.win32.win32.x86_64.eclipse&apos;, version(&apos;4.17.0.20200910-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.ui.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions&apos;, version(&apos;0.16.0.v20200507-0938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem.source&apos;, version(&apos;1.7.700.v20200110-1734&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.doc&apos;, version(&apos;1.2.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.core&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.mapping.source.feature.group&apos;, version(&apos;2.13.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.monitoring.source&apos;, version(&apos;1.1.800.v20200820-1401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.ide.application&apos;, version(&apos;4.17.0.I20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.feature.feature.jar&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.ui&apos;, version(&apos;1.8.500.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.externaltools.source&apos;, version(&apos;3.4.800.v20200612-0848&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apiguardian.source&apos;, version(&apos;1.1.0.v20190826-0900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher.source&apos;, version(&apos;1.5.800.v20200727-1323&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.util&apos;, version(&apos;3.5.300.v20190708-1141&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit.feature.group&apos;, version(&apos;2.14.0.v20190822-1451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.thirdparty.feature.jar&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.resources&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.source&apos;, version(&apos;3.10.100.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.doc&apos;, version(&apos;2.20.0.v20200630-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.core.refactoring&apos;, version(&apos;3.11.100.v20200720-0748&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.concurrent.source&apos;, version(&apos;1.1.500.v20200106-1437&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.dsl.feature.feature.jar&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xmi.source&apos;, version(&apos;2.16.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director&apos;, version(&apos;2.4.700.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analyzers-common.source&apos;, version(&apos;8.4.1.v20200122-1459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ant.source&apos;, version(&apos;2.11.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.artifact.repository&apos;, version(&apos;1.3.500.v20200406-2025&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.natives&apos;, version(&apos;1.3.600.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.ui.properties.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launcher.feature.group&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.ant.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.logging&apos;, version(&apos;1.2.15.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.runner.source&apos;, version(&apos;1.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.source&apos;, version(&apos;3.2.601.v20201025-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit.feature.jar&apos;, version(&apos;2.14.0.v20190822-1451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.webapp.source&apos;, version(&apos;3.10.0.v20200724-0708&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.db.h2&apos;, version(&apos;4.4.0.v20200412-0425&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.ui.examples.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.engine.emfvm.launch.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.ecore.converter.source.feature.group&apos;, version(&apos;2.12.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer&apos;, version(&apos;5.1.101.v20201025-2315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.sequence.ui&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.doc&apos;, version(&apos;1.4.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.doc&apos;, version(&apos;1.11.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.examples.installer.feature.group&apos;, version(&apos;4.3.2.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.feature.group&apos;, version(&apos;3.11.0.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.feature.group&apos;, version(&apos;2.23.0.v20200630-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.bindings&apos;, version(&apos;0.12.900.v20200513-0930&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.ext.awt&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.genericeditor&apos;, version(&apos;1.1.800.v20200828-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.commands.source&apos;, version(&apos;0.12.900.v20200110-1732&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.launching&apos;, version(&apos;1.2.1000.v20200610-1458&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.properties.ui.legacy&apos;, version(&apos;2.1.5.202008270808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.ui.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.feature.source.feature.jar&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.variables.source&apos;, version(&apos;3.4.800.v20200120-1101&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.model.workbench.source&apos;, version(&apos;2.1.800.v20200828-0938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.ui.source&apos;, version(&apos;4.2.0.v20200724-0708&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.edit&apos;, version(&apos;4.3.1.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.feature.group&apos;, version(&apos;2.19.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecp.common.ui&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.core.source&apos;, version(&apos;3.6.700.v20200828-0941&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatechecker&apos;, version(&apos;1.2.300.v20200222-1600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.uml.edit&apos;, version(&apos;5.10.100.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.ssl&apos;, version(&apos;1.2.400.v20200611-2220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench.texteditor&apos;, version(&apos;3.15.0.v20200812-2334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.editor&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher&apos;, version(&apos;1.5.800.v20200727-1323&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.compare.feature.jar&apos;, version(&apos;4.5.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ocl.source.feature.jar&apos;, version(&apos;1.12.2.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.annotations&apos;, version(&apos;1.6.600.v20191216-2352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.doc&apos;, version(&apos;1.11.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.runtime.source&apos;, version(&apos;1.1.0.v20180713-1646&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.views.common.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.ide.ui&apos;, version(&apos;4.4.3.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filebuffers&apos;, version(&apos;3.6.1000.v20200409-1035&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.source&apos;, version(&apos;3.9.101.v20201027-0547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem&apos;, version(&apos;1.7.700.v20200110-1734&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt&apos;, version(&apos;3.115.0.v20200831-1002&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.feature.jar&apos;, version(&apos;1.18.0.v20200901-1012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.update.configurator&apos;, version(&apos;3.4.600.v20200422-1910&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.resources.edit&apos;, version(&apos;1.11.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.util.ui.feature.jar&apos;, version(&apos;4.11.0.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.e3&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.databinding&apos;, version(&apos;1.12.0.v20200717-1533&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.feature.group&apos;, version(&apos;4.11.0.v20200901-1413&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.feature.jar&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.core.ext.widgets.reference&apos;, version(&apos;2.1.5.202008270808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.parser&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.completeocl&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.quicklinks&apos;, version(&apos;1.1.0.v20200724-0708&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.core.source&apos;, version(&apos;3.5.800.v20200608-1251&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.thirdparty.source.feature.jar&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation&apos;, version(&apos;1.8.0.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.testing.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.explorer&apos;, version(&apos;4.7.0.v20200825-1015&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.annotation&apos;, version(&apos;1.3.5.v20200504-1837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher.eclipse.source&apos;, version(&apos;1.3.700.v20200828-0839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui&apos;, version(&apos;1.9.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.debug.ui&apos;, version(&apos;3.12.0.v20200828-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.sdk.source.feature.group&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.modeling&apos;, version(&apos;4.17.0.20200910-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.adt.debug.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.edit.feature.group&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.edit.feature.group&apos;, version(&apos;2.13.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher.source&apos;, version(&apos;1.5.400.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.feature.jar&apos;, version(&apos;4.11.0.v20200902-0811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.lib.source&apos;, version(&apos;2.23.0.v20200831-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.common&apos;, version(&apos;4.11.0.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.ecore&apos;, version(&apos;2.10.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.i18n&apos;, version(&apos;1.13.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.workingsets.editor&apos;, version(&apos;1.12.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.user.ui.source.feature.jar&apos;, version(&apos;2.4.900.v20200828-0839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.workingsets.edit&apos;, version(&apos;1.11.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.sdk.feature.group&apos;, version(&apos;2.23.0.v20200822-0801&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.db.jdbc&apos;, version(&apos;4.4.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.swt.win32.source&apos;, version(&apos;1.0.700.v20200607-1314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.editor&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.server&apos;, version(&apos;4.10.0.v20200825-1015&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher.win32.win32.x86_64&apos;, version(&apos;1.1.1300.v20200819-0940&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.ant.source&apos;, version(&apos;1.10.8.v20200515-1239&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui.render.awt.source&apos;, version(&apos;1.8.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ocl.feature.jar&apos;, version(&apos;1.12.2.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.generator.source&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xmi&apos;, version(&apos;2.16.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.resources&apos;, version(&apos;1.14.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.examples.runtime.ui.pde.feature.jar&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.editor.source.feature.jar&apos;, version(&apos;2.14.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.ui.feature.group&apos;, version(&apos;2.23.0.v20200703-0737&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language.source&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.feature.jar&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt.theme.source&apos;, version(&apos;0.12.700.v20200527-0719&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.gef.ui.source&apos;, version(&apos;1.7.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change.source&apos;, version(&apos;2.14.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.services.source&apos;, version(&apos;1.3.700.v20190930-1643&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.compatibility&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.core.source&apos;, version(&apos;3.16.0.v20200828-0817&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.tcp&apos;, version(&apos;4.2.1.v20200825-0442&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.builder.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.jupiter.params.source&apos;, version(&apos;5.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.common.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.purexbase.ui.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.edit.feature.jar&apos;, version(&apos;2.13.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.examples.feature.group&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.feature.jar&apos;, version(&apos;6.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.source&apos;, version(&apos;1.3.500.v20200114-1637&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.action.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.codegen.ecore.ui.feature.group&apos;, version(&apos;2.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.httpclient&apos;, version(&apos;3.1.0.v201012070820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.ocl.source&apos;, version(&apos;2.0.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.event&apos;, version(&apos;1.5.500.v20200616-0800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.webapp&apos;, version(&apos;3.10.0.v20200724-0708&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.shared&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.source.feature.group&apos;, version(&apos;1.12.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.ui.ext&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.source&apos;, version(&apos;3.21.0.v20200821-1458&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.junit4.feature.feature.group&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.dom&apos;, version(&apos;1.6.1.v201505192100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.ui.source&apos;, version(&apos;1.3.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text.quicksearch&apos;, version(&apos;1.0.300.v20200519-2023&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launch.ui&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.dnd.ide&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.validity&apos;, version(&apos;2.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.type.ui&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.server&apos;, version(&apos;9.4.31.v20200723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.core.ui&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.debug.vm.ui&apos;, version(&apos;2.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.gmf.runtime&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.registry&apos;, version(&apos;1.2.0.v20200614-1851&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.source.feature.jar&apos;, version(&apos;1.6.700.v20200813-0739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher.eclipse&apos;, version(&apos;1.3.700.v20200828-0839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.jupiter.engine.source&apos;, version(&apos;5.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.edit.source&apos;, version(&apos;4.3.1.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.common.ui&apos;, version(&apos;2.1.5.202008270808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.ui&apos;, version(&apos;4.8.1.v20200825-1015&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.feature.group&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.core&apos;, version(&apos;1.2.0.v20200813-0526&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.source&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping&apos;, version(&apos;2.12.0.v20181104-0733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.uml.feature.group&apos;, version(&apos;5.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.garbagecollector&apos;, version(&apos;1.1.400.v20200221-1022&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.essentialocl&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.ide&apos;, version(&apos;4.17.0.I20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.ui.source&apos;, version(&apos;1.4.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text&apos;, version(&apos;3.10.300.v20200807-0831&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.ecore.importer.source&apos;, version(&apos;2.9.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ecore&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.commands&apos;, version(&apos;3.9.700.v20191217-1850&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.edit.source.feature.group&apos;, version(&apos;2.13.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.runtime.feature.jar&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.http&apos;, version(&apos;4.1.1.v20200528-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.util.ui.feature.group&apos;, version(&apos;4.11.0.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit&apos;, version(&apos;4.13.0.v20200204-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.ui.source&apos;, version(&apos;3.6.500.v20200828-1336&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.feature.jar&apos;, version(&apos;5.5.1.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.operations.source&apos;, version(&apos;2.5.900.v20200808-1311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.core.refactoring.source&apos;, version(&apos;3.11.100.v20200720-0748&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools.sdk.feature.jar&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emfforms.core.services.editsupport&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.jobs&apos;, version(&apos;3.10.800.v20200421-0950&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.examples.installer&apos;, version(&apos;4.2.1.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt.theme&apos;, version(&apos;0.12.700.v20200527-0719&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.ide.ui.feature.jar&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.java.source&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.trace.editor&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingepp.package.modeling.configuration&apos;, version(&apos;4.17.0.20200910-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.ide.executable.win32.win32.x86_64&apos;, version(&apos;4.17.0.I20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.ui.source.feature.group&apos;, version(&apos;2.23.0.v20200703-0737&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.diagram.gmf.feature.jar&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.userstorage&apos;, version(&apos;1.2.0.v20190307-0457&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit&apos;, version(&apos;2.16.0.v20190920-0401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.feature.group&apos;, version(&apos;2.23.0.v20200701-0840&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.dom.smil.source&apos;, version(&apos;1.0.1.v200903091627&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.editor.source&apos;, version(&apos;2.17.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.jarprocessor.source&apos;, version(&apos;1.1.600.v20200217-1130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro&apos;, version(&apos;3.5.1100.v20200828-0803&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.console.source&apos;, version(&apos;1.4.200.v20200828-1034&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpclient.source&apos;, version(&apos;4.5.10.v20200830-2311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclient45.feature.source.feature.group&apos;, version(&apos;1.0.702.v20201025-2303&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.editors&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.source.feature.jar&apos;, version(&apos;2.20.0.v20200822-0801&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.printing&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.feature.jar&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.jupiter.migrationsupport&apos;, version(&apos;5.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.source.feature.group&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2&apos;, version(&apos;5.5.1.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.feature.jar&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools.sdk_root&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.antlr.runtime&apos;, version(&apos;3.2.0.v201101311130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.antlr.runtime&apos;, version(&apos;4.7.2.v20221112-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.tools.services&apos;, version(&apos;4.8.400.v20200217-1142&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.adt.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.sdk.feature.jar&apos;, version(&apos;5.5.1.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.net.source&apos;, version(&apos;1.3.800.v20200422-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.suite.api.source&apos;, version(&apos;1.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util.gui&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.addons.swt&apos;, version(&apos;1.3.1100.v20200703-0611&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.editor.properties&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.expressions.editor&apos;, version(&apos;4.4.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.source&apos;, version(&apos;2.8.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.converter.source.feature.group&apos;, version(&apos;2.15.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui.feature.group&apos;, version(&apos;2.17.0.v20190507-0402&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.forms.source&apos;, version(&apos;3.10.0.v20200727-0948&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.core.emf.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools.doc&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.core.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.ui&apos;, version(&apos;1.3.1000.v20200610-0847&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.purexbase.ide&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.doc.isv&apos;, version(&apos;3.14.900.v20200902-1022&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.servlet.source&apos;, version(&apos;3.1.0.v201410161800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.source.feature.jar&apos;, version(&apos;4.17.0.v20200831-1002&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.dnd&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatesite&apos;, version(&apos;1.1.400.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.registry.source&apos;, version(&apos;3.9.0.v20200625-1425&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.p2.reconciler.dropins&apos;, version(&apos;4.17.0.I20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin.source&apos;, version(&apos;2.1.400.v20191002-0702&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.lib&apos;, version(&apos;2.23.0.v20200831-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.action&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.sdk.feature.jar&apos;, version(&apos;2.23.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.impactanalyzer.util&apos;, version(&apos;3.10.500.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.expressions&apos;, version(&apos;4.4.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.editor.source&apos;, version(&apos;2.8.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.cdo.feature.source.feature.jar&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.sdk.feature.jar&apos;, version(&apos;3.10.100.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.junit.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change&apos;, version(&apos;2.14.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.runtime&apos;, version(&apos;3.6.900.v20200612-1330&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.common&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.testing&apos;, version(&apos;2.23.0.v20200831-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.resources.editor.ide.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.ui.source&apos;, version(&apos;1.2.700.v20200807-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launcher.source.feature.jar&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.property.source&apos;, version(&apos;1.8.100.v20200619-0651&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.user.ui.feature.jar&apos;, version(&apos;2.4.900.v20200828-0839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.model.workbench&apos;, version(&apos;2.1.800.v20200828-0938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.shared&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench.source&apos;, version(&apos;3.120.0.v20200829-1411&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.traceability.model&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingepp.package.modeling.config.win32.win32.x86_64&apos;, version(&apos;4.17.0.20200910-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.db.feature.group&apos;, version(&apos;4.11.0.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.jupiter.api.source&apos;, version(&apos;5.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.bidi&apos;, version(&apos;1.3.0.v20200612-1624&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecp.view.label.model&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata.source&apos;, version(&apos;2.5.0.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.source.feature.jar&apos;, version(&apos;3.14.500.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.common.ide&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.source.feature.group&apos;, version(&apos;3.18.500.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.model&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.engine.emfvm&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.source&apos;, version(&apos;2.23.0.v20200701-0840&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ide&apos;, version(&apos;2.23.0.v20200831-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.source&apos;, version(&apos;3.23.0.v20200828-0941&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.examples.installer.feature.jar&apos;, version(&apos;4.3.1.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.ssl.feature.source.feature.jar&apos;, version(&apos;1.1.400.v20200812-2314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit4.runtime&apos;, version(&apos;1.1.1300.v20200720-0748&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.codegen.ecore&apos;, version(&apos;2.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpcore&apos;, version(&apos;4.4.12.v20200108-1212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.lib.source&apos;, version(&apos;1.1.400.v20191119-0943&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.common.feature.group&apos;, version(&apos;2.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.ui.examples&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui&apos;, version(&apos;3.118.0.v20200807-0902&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.generator&apos;, version(&apos;2.23.0.v20200831-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.engine.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.util.source&apos;, version(&apos;2.23.0.v20200831-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.properties&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.core&apos;, version(&apos;2.1.5.202008270808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.ui.team&apos;, version(&apos;4.3.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.feature.group&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.ecore.importer&apos;, version(&apos;3.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2ecore.source&apos;, version(&apos;2.11.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.source.feature.group&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.cdo.feature.feature.group&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds1_2.lib&apos;, version(&apos;1.0.400.v20191119-0943&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.server.admin&apos;, version(&apos;4.3.1.v20200825-1015&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd&apos;, version(&apos;2.18.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools.ui&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.identity.source&apos;, version(&apos;3.9.401.v20201027-0550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.examples.installer.feature.jar&apos;, version(&apos;4.3.2.v20200901-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.dom.smil&apos;, version(&apos;1.0.1.v200903091627&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.trace.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.doc.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.properties.tabbed.source&apos;, version(&apos;3.8.1000.v20200609-0849&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ide&apos;, version(&apos;2.23.0.v20200831-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.dom.svg&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.converter.feature.group&apos;, version(&apos;2.15.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata.repository.source&apos;, version(&apos;1.3.400.v20191211-1528&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.common.edit.feature.jar&apos;, version(&apos;2.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.event&apos;, version(&apos;4.17.0.I20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.render.source&apos;, version(&apos;1.7.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.examples.runtime.diagram.geoshapes&apos;, version(&apos;1.8.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;io.github.classgraph&apos;, version(&apos;4.8.35.v20190528-1517&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde&apos;, version(&apos;3.13.1200.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.type.ui.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.doc.isv&apos;, version(&apos;4.17.0.v20200902-1022&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.rose.source&apos;, version(&apos;2.10.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util&apos;, version(&apos;1.13.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.feature.jar&apos;, version(&apos;4.11.0.v20200901-1413&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.dsls&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.command&apos;, version(&apos;1.0.2.v20170914-1324&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.tools.feature.feature.jar&apos;, version(&apos;4.18.0.v20201026-0947&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codemining.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.annotations&apos;, version(&apos;7.0.0.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.doc.feature.group&apos;, version(&apos;1.12.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.widgets.source&apos;, version(&apos;1.2.700.v20191222-1048&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.lib&apos;, version(&apos;2.23.0.v20200831-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.ide.ini.win32.win32.x86_64&apos;, version(&apos;4.17.0.I20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.ecore.converter&apos;, version(&apos;2.8.0.v20180706-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.source.feature.group&apos;, version(&apos;1.6.700.v20200813-0739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.profiler.model.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.launcher.source&apos;, version(&apos;1.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.ui&apos;, version(&apos;1.2.700.v20200807-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.sdk.feature.group&apos;, version(&apos;1.12.2.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.core.source&apos;, version(&apos;8.4.1.v20200122-1459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.win32&apos;, version(&apos;1.2.800.v20200127-1343&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.printing.render.source&apos;, version(&apos;1.8.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.source&apos;, version(&apos;1.11.400.v20200828-0938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.xsd2ecore&apos;, version(&apos;2.9.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.rcp.feature.feature.jar&apos;, version(&apos;1.4.900.v20200813-0739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.dom.events.source&apos;, version(&apos;3.0.0.draft20060413_v201105210656&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.doc.feature.group&apos;, version(&apos;3.14.400.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.shell&apos;, version(&apos;1.1.0.v20180713-1646&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.parser.source&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.tools.emf.ui&apos;, version(&apos;4.6.1000.v20201009-1503&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.pivot&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2&apos;, version(&apos;1.14.0.v20200624-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.dsl&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.edit&apos;, version(&apos;1.8.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.converter&apos;, version(&apos;2.10.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.typesystem.emf&apos;, version(&apos;2.2.0.v201605260315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change.edit.source&apos;, version(&apos;2.8.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.diagram.sirius.feature.jar&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.feature.jar&apos;, version(&apos;3.14.400.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.operations&apos;, version(&apos;2.5.900.v20200808-1311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.console&apos;, version(&apos;3.9.300.v20200828-0817&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.dom.events&apos;, version(&apos;3.0.0.draft20060413_v201105210656&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.ecore.source&apos;, version(&apos;2.10.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.doc.feature.group&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.tablecombo&apos;, version(&apos;1.2.0.202009071539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.ide&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.source&apos;, version(&apos;2.23.0.v20200630-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.junit4.feature.source.feature.jar&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.doc.feature.group&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.converter.feature.jar&apos;, version(&apos;2.15.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.acceleo.aql&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.ui.shared&apos;, version(&apos;4.4.1.v20200330-1311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.emf.validation.validity.ui&apos;, version(&apos;2.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.util.source&apos;, version(&apos;3.5.300.v20190708-1141&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.logging&apos;, version(&apos;1.2.0.v20180409-1502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2xml.source&apos;, version(&apos;2.11.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.compiler.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclient45.feature.feature.jar&apos;, version(&apos;1.0.702.v20201025-2303&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.editor.feature.group&apos;, version(&apos;2.17.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.bidi.source&apos;, version(&apos;1.3.0.v20200612-1624&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.feature.feature.group&apos;, version(&apos;3.14.1702.v20201025-2315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.annotations.source&apos;, version(&apos;1.6.600.v20191216-2352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.natives.source&apos;, version(&apos;1.3.600.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2ecore.editor&apos;, version(&apos;2.10.0.v20181104-0733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.core.source&apos;, version(&apos;0.12.1300.v20200615-1701&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.commands.core&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.log4j&apos;, version(&apos;1.2.15.v201012070815&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.security.ui&apos;, version(&apos;4.4.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.jxpath.source&apos;, version(&apos;1.3.0.v200911051830&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.source&apos;, version(&apos;1.9.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.impactanalyzer&apos;, version(&apos;3.10.500.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.search.source&apos;, version(&apos;3.12.0.v20200727-2017&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.ecore.converter.source.feature.jar&apos;, version(&apos;2.12.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.core&apos;, version(&apos;8.4.1.v20200122-1459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.shared.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe.core&apos;, version(&apos;1.5.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.feature.jar&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.ui.testing&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ecore.extender&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.css.sac&apos;, version(&apos;1.3.1.v200903091627&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.editors&apos;, version(&apos;3.13.300.v20200812-2334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.docs.feature.jar&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.feature.group&apos;, version(&apos;2.23.0.v20200822-0801&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.externaltools&apos;, version(&apos;1.1.700.v20200416-1310&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.graph.feature.group&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.doc&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.core.ant.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore&apos;, version(&apos;2.23.0.v20200701-0840&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.rcp.ui&apos;, version(&apos;4.4.2.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.e3.ui&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.vintage.engine&apos;, version(&apos;5.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.css.source&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.css.source&apos;, version(&apos;1.13.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.ui&apos;, version(&apos;3.21.200.v20200828-0853&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.feature.source.feature.group&apos;, version(&apos;3.14.1702.v20201025-2315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.engine&apos;, version(&apos;2.6.700.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.sdk.feature.jar&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.unified.feature.group&apos;, version(&apos;4.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench&apos;, version(&apos;1.11.400.v20200828-0938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.launching&apos;, version(&apos;3.9.0.v20200812-1037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.gef.ui&apos;, version(&apos;1.7.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.unified.ui.feature.group&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.el.source&apos;, version(&apos;2.2.0.v201303151357&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;lpg.runtime.java&apos;, version(&apos;2.0.17.v201004271640&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.source.feature.jar&apos;, version(&apos;1.12.2.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.edit.source&apos;, version(&apos;1.8.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples&apos;, version(&apos;3.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.annotations.source&apos;, version(&apos;1.1.400.v20190929-1236&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.purexbase.ui&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna.source&apos;, version(&apos;4.5.1.v20190425-1842&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.feature.jar&apos;, version(&apos;2.20.0.v20200822-0801&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui&apos;, version(&apos;1.9.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator&apos;, version(&apos;3.9.400.v20200723-2304&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.essentialocl.ui&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extras.feature.feature.jar&apos;, version(&apos;1.4.900.v20200828-0839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.ide.ui&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.feature.group&apos;, version(&apos;4.17.0.v20200831-1002&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.dsl.ui&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface&apos;, version(&apos;3.21.0.v20200821-1458&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.aql.feature.jar&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.cheatsheets&apos;, version(&apos;2.8.0.v20180706-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.workspace&apos;, version(&apos;4.3.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.ui.source.feature.jar&apos;, version(&apos;2.23.0.v20200703-0737&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.core.source&apos;, version(&apos;1.2.0.v20200813-0526&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.source&apos;, version(&apos;1.10.0.v20200815-1752&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.transfer.workspace.ui&apos;, version(&apos;4.3.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.genericeditor.diff.extension&apos;, version(&apos;1.0.600.v20200212-1524&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.codegen.ecore.ui&apos;, version(&apos;2.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.tools.compat&apos;, version(&apos;4.8.0.v20201026-0947&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.ext.widgets.reference.edit&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.query.source&apos;, version(&apos;1.7.0.201805030653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.registry.source&apos;, version(&apos;1.2.0.v20200614-1851&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.admin&apos;, version(&apos;4.2.0.v20200311-1912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction&apos;, version(&apos;1.9.1.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.mapping.source.feature.jar&apos;, version(&apos;2.13.0.v20200723-0820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.doc&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.ssl.feature.feature.group&apos;, version(&apos;1.1.400.v20200812-2314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.rose&apos;, version(&apos;2.10.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.http.common&apos;, version(&apos;4.1.1.v20200528-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.xtext.console&apos;, version(&apos;4.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.feature.jar&apos;, version(&apos;4.17.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.doc&apos;, version(&apos;4.2.1.v20200330-1311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin.equinox.source&apos;, version(&apos;1.1.400.v20200319-1546&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator.resources&apos;, version(&apos;3.7.400.v20200722-0751&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cdo.epp.feature.group&apos;, version(&apos;4.11.0.v20200902-0811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.purexbase.ide.source&apos;, version(&apos;2.23.0.v20200831-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.editors.common.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.action.ide.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.universal&apos;, version(&apos;3.4.0.v20200805-1259&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.action.ide&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.thirdparty.source.feature.group&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.providers.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.core&apos;, version(&apos;3.5.800.v20200608-1251&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ocl&apos;, version(&apos;1.4.0.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.doc&apos;, version(&apos;2.23.0.v20200831-0856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.wizards.source&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.ide.ui.source.feature.group&apos;, version(&apos;3.3.12.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.services.source&apos;, version(&apos;3.9.0.v20200511-1725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.continuation.source&apos;, version(&apos;9.4.31.v20200723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.codec&apos;, version(&apos;1.13.0.v20200108-0001&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.codec&apos;, version(&apos;1.14.0.v20200818-1422&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.runtime.sdk.feature.jar&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.quicklinks.source&apos;, version(&apos;1.1.0.v20200724-0708&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ui.source.feature.group&apos;, version(&apos;2.13.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.css&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.css&apos;, version(&apos;1.13.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.adt.editor&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.engine.emfvm.launch&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.core&apos;, version(&apos;0.12.1300.v20200615-1701&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.dom.svg.source&apos;, version(&apos;1.1.0.v201011041433&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language&apos;, version(&apos;2.11.3.v20200520-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.junit.runtime&apos;, version(&apos;3.5.900.v20200810-0835&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.sdk&apos;, version(&apos;5.5.1.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core&apos;, version(&apos;2.6.300.v20200211-1504&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.java.source&apos;, version(&apos;2.11.0.v20200324-0723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.common.ui&apos;, version(&apos;3.7.12.202211151354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.base.source&apos;, version(&apos;4.3.0.v20200902-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.diagram&apos;, version(&apos;2.5.2.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.logging.source&apos;, version(&apos;1.2.0.v20180409-1502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xerces&apos;, version(&apos;2.9.0.v201101211617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.sdk.feature.group&apos;, version(&apos;3.11.0.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.runtime.source&apos;, version(&apos;3.5.300.v20200720-0748&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.source.feature.jar&apos;, version(&apos;2.23.0.v20200701-0840&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.examples.feature.group&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.launcher&apos;, version(&apos;1.6.0.v20200203-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.eventmanager&apos;, version(&apos;3.10.500.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.examples.uml.ui&apos;, version(&apos;5.5.0.v20200302-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.junit4.source&apos;, version(&apos;2.23.0.v20200831-0808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.editor.table&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.table&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide&apos;, version(&apos;3.17.200.v20200808-0622&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.examples.ui.pde&apos;, version(&apos;3.11.0.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.source&apos;, version(&apos;1.8.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.source&apos;, version(&apos;2.21.0.v20200708-0547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.runtime.feature.group&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.debug.core.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.interpreter&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.printing.source&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.emftvm.trace.edit.source&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.net4j.http.server&apos;, version(&apos;4.1.1.v20200528-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui.render.source&apos;, version(&apos;1.7.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.jreinfo.ui&apos;, version(&apos;1.12.0.v20200720-0749&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.tools.feature.feature.group&apos;, version(&apos;4.18.0.v20201026-0947&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.ant&apos;, version(&apos;1.10.8.v20200515-1239&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.core.ui.vm&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.generator.common&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.examples&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.compare.diagram.edit&apos;, version(&apos;2.5.2.202008311302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security&apos;, version(&apos;1.3.500.v20200114-1637&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.properties&apos;, version(&apos;1.8.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.all.sdk.feature.group&apos;, version(&apos;5.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.edit.source.feature.group&apos;, version(&apos;1.7.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.source.feature.group&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.edit.feature.group&apos;, version(&apos;5.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.atl.examples.feature.jar&apos;, version(&apos;4.2.1.v202006221222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.source&apos;, version(&apos;5.1.101.v20201025-2315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.runtime.source&apos;, version(&apos;3.6.900.v20200612-1330&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ui.source&apos;, version(&apos;2.10.0.v20181104-0733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ui.feature.jar&apos;, version(&apos;2.13.0.v20190323-1059&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.ide.common.source&apos;, version(&apos;2.23.0.v20200831-0856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.base.edit&apos;, version(&apos;1.13.0.v20200720-0841&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.uml.ui&apos;, version(&apos;2.12.100.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.feature.group&apos;, version(&apos;2.23.0.v20200831-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2ecore&apos;, version(&apos;2.11.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.ui&apos;, version(&apos;1.15.0.v20200820-0414&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.importexport&apos;, version(&apos;1.2.500.v20200731-1005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.feature.feature.group&apos;, version(&apos;6.4.1.202012210908&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecoretools&apos;, version(&apos;3.3.2.201909230743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecp.common&apos;, version(&apos;1.25.0.20200831-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.parsley.editors.common&apos;, version(&apos;1.12.0.v20200831-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.oclinecore&apos;, version(&apos;1.13.0.v20201208-2229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.org.eclipse.update.feature.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='epp.package.modeling' version='4.17.0.20200910-1200'>
      <update id='epp.package.modeling' range='[4.6.0.20160301-1200,4.17.0.20200910-1200)' severity='0' description='Eclipse package upgrade from versions before Eclipse Neon (4.6) is not possible. See bug 332989.'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Eclipse Modeling Tools'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='org.eclipse.equinox.p2.description' value='2020-09 Release of the Eclipse Modeling Tools package.'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Packaging Project'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='epp.package.modeling' version='4.17.0.20200910-1200'/>
      </provides>
      <requires size='37'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.package.modeling.feature.feature.group' range='[4.17.0.20200910-1200,4.17.0.20200910-1200]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.transaction.sdk.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tips.feature.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext_feature.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.cdo.epp.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.package.common.feature.feature.group' range='[4.17.0.20200910-1200,4.17.0.20200910-1200]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.source.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingepp.package.modeling.application' range='[4.17.0.20200910-1200,4.17.0.20200910-1200]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sdk.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.ide.ui.source.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.sdk.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gef.sdk.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.sdk.source.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='osgi.ee' name='JavaSE' range='[11.0.0,11.0.0]'>
          <filter>
            (osgi.os=linux)
          </filter>
        </required>
        <required namespace='osgi.ee' name='JavaSE' range='[11.0.0,11.0.0]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' range='[4.17.0.v20200902-1800,4.17.0.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecp.emfforms.sdk.feature.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='osgi.ee' name='JavaSE' range='[11.0.0,11.0.0]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingepp.package.modeling.configuration' range='[4.17.0.20200910-1200,4.17.0.20200910-1200]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.diagram.sirius.source.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.egit.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ocl.all.sdk.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.sdk.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.sdk.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.query.sdk.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.uml2.sdk.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.design.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.tools.feature.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gmf.runtime.sdk.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.validation.sdk.feature.group' range='0.0.0'>
          <filter>
            (org.eclipse.epp.install.roots=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <licenses size='1'>
        <license uri='http://eclipse.org/legal/epl/notice.php' url='http://eclipse.org/legal/epl/notice.php'>
          Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;    delivering, extending, and upgrading the Content. Typical modules may&#xA;    include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;    features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;    (Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;    associated material. Each Feature may be packaged as a sub-directory in a&#xA;    directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;    contain a list of the names and version numbers of the Plug-ins and/or&#xA;    Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;    Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;    version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;    http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;    http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;    http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;    http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;    http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;    http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;    execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;    intent of installing, extending or updating the functionality of an&#xA;    Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;    party Installable Software or a portion thereof to be accessed and copied to&#xA;    the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;    conditions that govern the use of the Installable Software (&quot;Installable&#xA;    Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;    accessed from the Target Machine in accordance with the Specification. Such&#xA;    Installable Software Agreement must inform the user of the terms and&#xA;    conditions that govern the Installable Software and must solicit acceptance&#xA;    by the end user in the manner prescribed in such Installable&#xA;    Software Agreement. Upon such indication of agreement by the user, the&#xA;    provisioning Technology will complete installation of the&#xA;    Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.
        </license>
      </licenses>
    </unit>
    <unit id='epp.package.modeling.executable.win32.win32.x86_64' version='4.17.0.20200910-1200'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='epp.package.modeling.executable.win32.win32.x86_64' version='4.17.0.20200910-1200'/>
        <provided namespace='toolingepp.package.modeling' name='epp.package.modeling.executable' version='4.17.0.20200910-1200'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='epp.package.modeling.executable.win32.win32.x86_64' version='4.17.0.20200910-1200'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='org.eclipse.acceleo.feature.group' version='3.7.12.202211151354' singleton='false'>
      <update id='org.eclipse.acceleo.feature.group' range='[0.0.0,3.7.12.202211151354)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.acceleo.features'/>
        <property name='maven-artifactId' value='org.eclipse.acceleo'/>
        <property name='maven-version' value='3.7.12-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2008, 2012 Obeo, France. &#xA;All rights reserved. This program and the accompanying materials &#xA;are made available under the terms of the Eclipse Public License v1.0 &#xA;which accompanies this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html &#xA;&#xA;Contributors: &#xA;Obeo - initial API and implementation'/>
        <property name='df_LT.featureName' value='Acceleo'/>
        <property name='df_LT.description' value='Acceleo is an template-based code generator used to generate any kind of code from any of EMF-based model.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.feature.group' version='3.7.12.202211151354'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.engine' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.ide.ui' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.model' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.parser' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.common' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.common.ide' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.doc' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.compatibility' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.compatibility.ui' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.model.edit' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.profiler' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.profiler.edit' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.profiler.editor' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.traceability' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.traceability.model' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.common.ui' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.ui.interpreter' range='[3.7.12.202211151354,3.7.12.202211151354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.acceleo.feature.jar' range='[3.7.12.202211151354,3.7.12.202211151354]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='%25copyrightURL' url='%25copyrightURL'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.e4.core.tools.feature.feature.group' version='4.18.0.v20201026-0947' singleton='false'>
      <update id='org.eclipse.e4.core.tools.feature.feature.group' range='[0.0.0,4.18.0.v20201026-0947)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='eclipse.platform.ui.tools'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.tools.feature'/>
        <property name='maven-version' value='4.18.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2010 BestSolution.at, Soyatec and others.'/>
        <property name='df_LT.featureName' value='Eclipse e4 Tools'/>
        <property name='df_LT.description' value='Eclipse e4 Model Tooling'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.tools.feature.feature.group' version='4.18.0.v20201026-0947'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.tools.emf.editor3x' range='[4.7.600.v20200723-1429,4.7.600.v20200723-1429]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.tools.emf.ui' range='[4.6.1000.v20201009-1503,4.6.1000.v20201009-1503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.tools.compat' range='[4.8.0.v20201026-0947,4.8.0.v20201026-0947]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.tools.services' range='[4.8.400.v20200217-1142,4.8.400.v20200217-1142]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.tools' range='[4.9.0.v20200923-1123,4.9.0.v20200923-1123]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.tools.jdt.templates' range='[4.8.400.v20191115-2149,4.8.400.v20191115-2149]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.tools.feature.feature.jar' range='[4.18.0.v20201026-0947,4.18.0.v20201026-0947]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.cdo.epp.feature.group' version='4.11.0.v20200902-0811' singleton='false'>
      <update id='org.eclipse.emf.cdo.epp.feature.group' range='[0.0.0,4.11.0.v20200902-0811)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.cdo.features'/>
        <property name='maven-artifactId' value='org.eclipse.emf.cdo.epp'/>
        <property name='maven-version' value='4.11.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2004-2020 Eike Stepper (Loehne, Germany) and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html'/>
        <property name='df_LT.featureName' value='CDO Model Repository EPP'/>
        <property name='df_LT.description' value='Contains the minimum CDO client and server environment for the Eclipse Modeling package.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.cdo.epp.feature.group' version='4.11.0.v20200902-0811'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.cdo.feature.group' range='[4.11.0.v20200902-0811,4.11.0.v20200902-0811]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.cdo.server.feature.group' range='[4.11.0.v20200902-0811,4.11.0.v20200902-0811]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.net4j.feature.group' range='[4.11.0.v20200901-1413,4.11.0.v20200901-1413]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.net4j.db.feature.group' range='[4.11.0.v20200901-0616,4.11.0.v20200901-0616]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.cdo.server.db.feature.group' range='[4.9.1.v20200901-0616,4.9.1.v20200901-0616]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.cdo.examples.installer.feature.group' range='[4.3.2.v20200901-0616,4.3.2.v20200901-0616]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.net4j.examples.installer.feature.group' range='[4.3.1.v20200901-0616,4.3.1.v20200901-0616]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.cdo.compare.feature.group' range='[4.5.0.v20200311-1912,4.5.0.v20200311-1912]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.cdo.doc.feature.group' range='[4.3.1.v20200330-1311,4.3.1.v20200330-1311]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.cdo.migrator' range='[3.2.0.v20200825-0917,3.2.0.v20200825-0917]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.cdo.epp.feature.jar' range='[4.11.0.v20200902-0811,4.11.0.v20200902-0811]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='%25copyrightURL' url='%25copyrightURL'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.compare.diagram.sirius.source.feature.group' version='3.3.12.202008311302' singleton='false'>
      <update id='org.eclipse.emf.compare.diagram.sirius.source.feature.group' range='[0.0.0,3.3.12.202008311302)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.compare.features'/>
        <property name='maven-artifactId' value='org.eclipse.emf.compare.diagram.sirius'/>
        <property name='maven-version' value='3.3.12-SNAPSHOT'/>
        <property name='maven-classifier' value='sources-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2015 Obeo, France. &#xA;All rights reserved. This program and the accompanying materials &#xA;are made available under the terms of the Eclipse Public License v1.0 &#xA;which accompanies this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html &#xA;&#xA;Contributors: &#xA;Obeo - initial API and implementation'/>
        <property name='df_LT.featureName' value='Model comparison (EMF Compare) - Sirius support (Experimental)- SDK'/>
        <property name='df_LT.description' value='Provides better support for Sirius diagrams comparison and difference visualization through EMF Compare.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.diagram.sirius.source.feature.group' version='3.3.12.202008311302'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.diagram.sirius.feature.group' range='[3.3.12.202008311302,3.3.12.202008311302]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.diagram.ide.ui.sirius.source' range='[1.1.1.202008311302,1.1.1.202008311302]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.diagram.sirius.source' range='[1.1.0.202008311302,1.1.0.202008311302]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.diagram.sirius.source.feature.jar' range='[3.3.12.202008311302,3.3.12.202008311302]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='%25copyrightURL' url='%25copyrightURL'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.compare.ide.ui.source.feature.group' version='3.3.12.202008311302' singleton='false'>
      <update id='org.eclipse.emf.compare.ide.ui.source.feature.group' range='[0.0.0,3.3.12.202008311302)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.compare.features'/>
        <property name='maven-artifactId' value='org.eclipse.emf.compare.ide.ui'/>
        <property name='maven-version' value='3.3.12-SNAPSHOT'/>
        <property name='maven-classifier' value='sources-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2006, 2015 Obeo, France. &#xA;All rights reserved. This program and the accompanying materials &#xA;are made available under the terms of the Eclipse Public License v1.0 &#xA;which accompanies this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html &#xA;&#xA;Contributors: &#xA;Obeo - initial API and implementation'/>
        <property name='df_LT.featureName' value='Model comparison (EMF Compare) - SDK'/>
        <property name='df_LT.description' value='This will provide EMF Compare with an UI integrated with the standard Team actions for comparison (&apos;Compare With &gt;&apos; menu).'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.ide.ui.source.feature.group' version='3.3.12.202008311302'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.ide.ui.feature.group' range='[3.3.12.202008311302,3.3.12.202008311302]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.edit.source' range='[4.3.1.202008311302,4.3.1.202008311302]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.ide.source' range='[3.4.3.202008311302,3.4.3.202008311302]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.ide.ui.source' range='[4.4.3.202008311302,4.4.3.202008311302]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.ide.ui.source.feature.jar' range='[3.3.12.202008311302,3.3.12.202008311302]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='%25copyrightURL' url='%25copyrightURL'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.compare.source.feature.group' version='3.3.12.202008311302' singleton='false'>
      <update id='org.eclipse.emf.compare.source.feature.group' range='[0.0.0,3.3.12.202008311302)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.compare.features'/>
        <property name='maven-artifactId' value='org.eclipse.emf.compare'/>
        <property name='maven-version' value='3.3.12-SNAPSHOT'/>
        <property name='maven-classifier' value='sources-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2006, 2015 Obeo, France. &#xA;All rights reserved. This program and the accompanying materials &#xA;are made available under the terms of the Eclipse Public License v1.0 &#xA;which accompanies this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html &#xA;&#xA;Contributors: &#xA;Obeo - initial API and implementation'/>
        <property name='df_LT.featureName' value='Model comparison (EMF Compare) - Core - SDK'/>
        <property name='df_LT.description' value='EMF Compare provides model comparison support for any EMF model to Eclipse.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.source.feature.group' version='3.3.12.202008311302'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.feature.group' range='[3.3.12.202008311302,3.3.12.202008311302]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.source' range='[3.5.3.202008311302,3.5.3.202008311302]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.compare.source.feature.jar' range='[3.3.12.202008311302,3.3.12.202008311302]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='%25copyrightURL' url='%25copyrightURL'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.ecoretools.design.feature.group' version='3.3.2.201909230743' singleton='false'>
      <update id='org.eclipse.emf.ecoretools.design.feature.group' range='[0.0.0,3.3.2.201909230743)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://wiki.eclipse.org/index.php/Ecore_Tools'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.ecoretools.features'/>
        <property name='maven-artifactId' value='org.eclipse.emf.ecoretools.design'/>
        <property name='maven-version' value='3.3.2-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='Ecore Diagram Editor'/>
        <property name='df_LT.description' value='Ecore Diagram Editor (Sirius based)'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.design.feature.group' version='3.3.2.201909230743'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.runtime.feature.group' range='5.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.runtime.aql.feature.group' range='5.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.runtime.ide.ui.feature.group' range='5.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.properties.feature.feature.group' range='5.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools' range='[3.3.2.201909230743,3.3.2.201909230743]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.ui' range='[3.3.2.201909230743,3.3.2.201909230743]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.design' range='[3.3.2.201909230743,3.3.2.201909230743]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.design.ui' range='[3.3.2.201909230743,3.3.2.201909230743]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.doc' range='[3.3.2.201909230743,3.3.2.201909230743]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.design.feature.jar' range='[3.3.2.201909230743,3.3.2.201909230743]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.design_root' range='[3.3.2.201909230743,3.3.2.201909230743]'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.eclipse.org/legal/epl-v10.html' url='http://www.eclipse.org/legal/epl-v10.html'>
        Copyright (c) 2007, 2010 Anyware Technologies and others&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.ecoretools.design_root' version='3.3.2.201909230743'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.design_root' version='3.3.2.201909230743'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.emf.ecoretools.design_root' version='3.3.2.201909230743'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.ecoretools.sdk.feature.group' version='3.3.2.201909230743' singleton='false'>
      <update id='org.eclipse.emf.ecoretools.sdk.feature.group' range='[0.0.0,3.3.2.201909230743)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://wiki.eclipse.org/index.php/Ecore_Tools'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.ecoretools.features'/>
        <property name='maven-artifactId' value='org.eclipse.emf.ecoretools.sdk'/>
        <property name='maven-version' value='3.3.2-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='Ecore Diagram Editor (SDK)'/>
        <property name='df_LT.description' value='Ecore Diagram Editor SDK includes runtime, source, and documentation'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.sdk.feature.group' version='3.3.2.201909230743'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.design.feature.group' range='[3.3.2.201909230743,3.3.2.201909230743]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.source' range='[3.3.2.201909230743,3.3.2.201909230743]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.doc' range='[3.3.2.201909230743,3.3.2.201909230743]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.tabbedproperties.source' range='[3.3.2.201909230743,3.3.2.201909230743]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.design.source' range='[3.3.2.201909230743,3.3.2.201909230743]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.design.properties.source' range='[3.3.2.201909230743,3.3.2.201909230743]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.sdk.feature.jar' range='[3.3.2.201909230743,3.3.2.201909230743]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.sdk_root' range='[3.3.2.201909230743,3.3.2.201909230743]'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.eclipse.org/legal/epl-v10.html' url='http://www.eclipse.org/legal/epl-v10.html'>
        Copyright (c) 2007, 2010 Anyware Technologies and others&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.ecoretools.sdk_root' version='3.3.2.201909230743'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecoretools.sdk_root' version='3.3.2.201909230743'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.emf.ecoretools.sdk_root' version='3.3.2.201909230743'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.feature.group' version='2.23.0.v20200822-0801' singleton='false'>
      <update id='org.eclipse.emf.feature.group' range='[0.0.0,2.23.0.v20200822-0801)' severity='0'/>
      <properties size='11'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.features'/>
        <property name='maven-artifactId' value='org.eclipse.emf'/>
        <property name='maven-version' value='2.23.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='EMF - Eclipse Modeling Framework Runtime and Tools'/>
        <property name='df_LT.description' value='The runtime and tools for EMF, without source or documentation.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.feature.group' version='2.23.0.v20200822-0801'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='20'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.feature.group' range='[2.20.0.v20200822-0801,2.20.0.v20200822-0801]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.ui.feature.group' range='[2.17.0.v20190507-0402,2.17.0.v20190507-0402]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.feature.group' range='[2.23.0.v20200630-0516,2.23.0.v20200630-0516]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.edit.feature.group' range='[2.16.0.v20190920-0401,2.16.0.v20190920-0401]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.edit.ui.feature.group' range='[2.19.0.v20200205-0529,2.19.0.v20200205-0529]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.edit.feature.group' range='[2.14.0.v20190822-1451,2.14.0.v20190822-1451]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.editor.feature.group' range='[2.17.0.v20190528-0725,2.17.0.v20190528-0725]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.codegen.feature.group' range='[2.21.0.v20200708-0547,2.21.0.v20200708-0547]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.codegen.ui.feature.group' range='[2.22.0.v20200424-0451,2.22.0.v20200424-0451]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.codegen.ecore.feature.group' range='[2.23.0.v20200701-0840,2.23.0.v20200701-0840]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.codegen.ecore.ui.feature.group' range='[2.23.0.v20200703-0737,2.23.0.v20200703-0737]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.converter.feature.group' range='[2.15.0.v20200324-0723,2.15.0.v20200324-0723]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.databinding.feature.group' range='[1.7.0.v20190323-1059,1.7.0.v20190323-1059]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.databinding.edit.feature.group' range='[1.7.0.v20190323-1059,1.7.0.v20190323-1059]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mapping.feature.group' range='[2.13.0.v20190323-1059,2.13.0.v20190323-1059]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mapping.ecore.feature.group' range='[2.12.0.v20190323-1059,2.12.0.v20190323-1059]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mapping.ui.feature.group' range='[2.13.0.v20190323-1059,2.13.0.v20190323-1059]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mapping.ecore.editor.feature.group' range='[2.14.0.v20190528-0725,2.14.0.v20190528-0725]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf' range='[2.8.0.v20180706-1146,2.8.0.v20180706-1146]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.feature.jar' range='[2.23.0.v20200822-0801,2.23.0.v20200822-0801]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.eclipse.org/legal/epl-v20.html' url='http://www.eclipse.org/legal/epl-v20.html'>
        Copyright (c) 2002-2018 IBM Corporation and others.&#xA;All rights reserved.   This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v2.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v20.html
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.parsley.sdk.feature.group' version='1.12.0.v20200831-1344' singleton='false'>
      <update id='org.eclipse.emf.parsley.sdk.feature.group' range='[0.0.0,1.12.0.v20200831-1344)' severity='0'/>
      <properties size='11'>
        <property name='org.eclipse.equinox.p2.name' value='EMF Parsley SDK'/>
        <property name='org.eclipse.equinox.p2.description' value='Working with EMF a developer realizes that all the information are available for building basic UI.&#xA;&#xA;A lightweight framework that allows easy and quick development of EMF-based Applications. Can be configured to use all kind of EMF persistence implementations (XMI, Teneo, CDO).&#xA;&#xA;It aims at providing a set of Components like Trees, Tables and Detail Forms that manage the model with the introspective EMF capabilities. Using these components you can easily build forms, viewer or editors. The framework provides basic UI implementations which are customizable with Injection mechanism (based on Google Guice).'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/emfparsley'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.parsley'/>
        <property name='maven-artifactId' value='org.eclipse.emf.parsley.sdk'/>
        <property name='maven-version' value='1.12.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2013 RCP Vision (http://www.rcp-vision.com) and others.&#xA;&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License&#xA;v1.0 which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html Description here.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.sdk.feature.group' version='1.12.0.v20200831-1344'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.dsl.feature.feature.group' range='[1.12.0.v20200831-1344,1.12.0.v20200831-1344]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.examples.feature.feature.group' range='[1.12.0.v20200831-1344,1.12.0.v20200831-1344]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.feature.feature.group' range='[1.12.0.v20200831-1344,1.12.0.v20200831-1344]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.junit4.feature.feature.group' range='[1.12.0.v20200831-1344,1.12.0.v20200831-1344]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.sdk.feature.jar' range='[1.12.0.v20200831-1344,1.12.0.v20200831-1344]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.eclipse.org/legal/epl-v10.html' url='http://www.eclipse.org/legal/epl-v10.html'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.parsley.sdk.source.feature.group' version='1.12.0.v20200831-1344' singleton='false'>
      <update id='org.eclipse.emf.parsley.sdk.source.feature.group' range='[0.0.0,1.12.0.v20200831-1344)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='EMF Parsley SDK Developer Resources'/>
        <property name='org.eclipse.equinox.p2.description' value='Working with EMF a developer realizes that all the information are available for building basic UI.&#xA;&#xA;A lightweight framework that allows easy and quick development of EMF-based Applications. Can be configured to use all kind of EMF persistence implementations (XMI, Teneo, CDO).&#xA;&#xA;It aims at providing a set of Components like Trees, Tables and Detail Forms that manage the model with the introspective EMF capabilities. Using these components you can easily build forms, viewer or editors. The framework provides basic UI implementations which are customizable with Injection mechanism (based on Google Guice).'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/emfparsley'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.parsley'/>
        <property name='maven-artifactId' value='org.eclipse.emf.parsley.sdk'/>
        <property name='maven-version' value='1.12.0-SNAPSHOT'/>
        <property name='maven-classifier' value='sources-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2013 RCP Vision (http://www.rcp-vision.com) and others.&#xA;&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License&#xA;v1.0 which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html Description here.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.sdk.source.feature.group' version='1.12.0.v20200831-1344'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.sdk.feature.group' range='[1.12.0.v20200831-1344,1.12.0.v20200831-1344]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.dsl.feature.source.feature.group' range='[1.12.0.v20200831-1344,1.12.0.v20200831-1344]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.examples.feature.source.feature.group' range='[1.12.0.v20200831-1344,1.12.0.v20200831-1344]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.feature.source.feature.group' range='[1.12.0.v20200831-1344,1.12.0.v20200831-1344]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.junit4.feature.source.feature.group' range='[1.12.0.v20200831-1344,1.12.0.v20200831-1344]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.parsley.sdk.source.feature.jar' range='[1.12.0.v20200831-1344,1.12.0.v20200831-1344]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.eclipse.org/legal/epl-v10.html' url='http://www.eclipse.org/legal/epl-v10.html'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.query.sdk.feature.group' version='1.12.0.201805030653' singleton='false'>
      <update id='org.eclipse.emf.query.sdk.feature.group' range='[0.0.0,1.12.0.201805030653)' severity='0'/>
      <properties size='11'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.query.features'/>
        <property name='maven-artifactId' value='org.eclipse.emf.query.sdk'/>
        <property name='maven-version' value='1.12.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='EMF Model Query SDK'/>
        <property name='df_LT.description' value='Binaries and API documentation and source zips for EMF Model Query.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.query.sdk.feature.group' version='1.12.0.201805030653'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.query.feature.group' range='[1.12.0.201805030653,1.12.0.201805030653]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.query.ocl.feature.group' range='[1.12.0.201805030653,1.12.0.201805030653]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.query.doc.feature.group' range='[1.12.0.201805030653,1.12.0.201805030653]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.query.source.feature.group' range='[1.12.0.201805030653,1.12.0.201805030653]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.query.ocl.source.feature.group' range='[1.12.0.201805030653,1.12.0.201805030653]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.query.sdk.feature.jar' range='[1.12.0.201805030653,1.12.0.201805030653]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.eclipse.org/legal/epl-v10.html' url='http://www.eclipse.org/legal/epl-v10.html'>
        Copyright (c) 2005, 2015 IBM Corporation and others.&#xA;All rights reserved.   This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.sdk.feature.group' version='2.23.0.v20200822-0801' singleton='false'>
      <update id='org.eclipse.emf.sdk.feature.group' range='[0.0.0,2.23.0.v20200822-0801)' severity='0'/>
      <properties size='11'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.features'/>
        <property name='maven-artifactId' value='org.eclipse.emf.sdk'/>
        <property name='maven-version' value='2.23.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='EMF - Eclipse Modeling Framework SDK'/>
        <property name='df_LT.description' value='The full EMF SDK, including source and documentation.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.sdk.feature.group' version='2.23.0.v20200822-0801'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.feature.group' range='[2.23.0.v20200822-0801,2.23.0.v20200822-0801]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.source.feature.group' range='[2.23.0.v20200822-0801,2.23.0.v20200822-0801]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.doc.feature.group' range='[2.22.0.v20200630-0516,2.22.0.v20200630-0516]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.example.installer' range='[1.10.0.v20200518-1440,1.10.0.v20200518-1440]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.sdk.feature.jar' range='[2.23.0.v20200822-0801,2.23.0.v20200822-0801]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.eclipse.org/legal/epl-v20.html' url='http://www.eclipse.org/legal/epl-v20.html'>
        Copyright (c) 2002-2018 IBM Corporation and others.&#xA;All rights reserved.   This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v2.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v20.html
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.transaction.sdk.feature.group' version='1.12.0.201805140824' singleton='false'>
      <update id='org.eclipse.emf.transaction.sdk.feature.group' range='[0.0.0,1.12.0.201805140824)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/modeling/emf/?project=transaction'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.transaction.features'/>
        <property name='maven-artifactId' value='org.eclipse.emf.transaction.sdk'/>
        <property name='maven-version' value='1.12.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='EMF Model Transaction SDK'/>
        <property name='df_LT.description' value='Binaries and API documentation and source zips for EMF Model Transaction.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.transaction.sdk.feature.group' version='1.12.0.201805140824'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.transaction.feature.group' range='[1.12.0.201805140824,1.12.0.201805140824]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.transaction.doc.feature.group' range='[1.12.0.201805140824,1.12.0.201805140824]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.workspace.feature.group' range='[1.12.0.201805140824,1.12.0.201805140824]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.workspace.doc.feature.group' range='[1.12.0.201805140824,1.12.0.201805140824]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.transaction.source.feature.group' range='[1.12.0.201805140824,1.12.0.201805140824]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.workspace.source.feature.group' range='[1.12.0.201805140824,1.12.0.201805140824]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.validation.sdk.feature.group' range='1.8.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.query.sdk.feature.group' range='1.8.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.transaction.sdk.feature.jar' range='[1.12.0.201805140824,1.12.0.201805140824]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.eclipse.org/legal/epl-v10.html' url='http://www.eclipse.org/legal/epl-v10.html'>
        Copyright (c) 2005, 2015 IBM Corporation and others.&#xA;All rights reserved.   This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.validation.sdk.feature.group' version='1.12.2.202008210805' singleton='false'>
      <update id='org.eclipse.emf.validation.sdk.feature.group' range='[0.0.0,1.12.2.202008210805)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/modeling/emf/?project=validation'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.validation.features'/>
        <property name='maven-artifactId' value='org.eclipse.emf.validation.sdk'/>
        <property name='maven-version' value='1.12.2-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='EMF Validation Framework SDK'/>
        <property name='df_LT.description' value='Binaries and API documentation and source zips for EMF Validation Framework.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.validation.sdk.feature.group' version='1.12.2.202008210805'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.validation.feature.group' range='[1.12.2.202008210805,1.12.2.202008210805]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.validation.ocl.feature.group' range='[1.12.2.202008210805,1.12.2.202008210805]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.validation.doc.feature.group' range='[1.12.2.202008210805,1.12.2.202008210805]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.validation.source.feature.group' range='[1.12.2.202008210805,1.12.2.202008210805]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.validation.ocl.source.feature.group' range='[1.12.2.202008210805,1.12.2.202008210805]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.validation.sdk.feature.jar' range='[1.12.2.202008210805,1.12.2.202008210805]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.eclipse.org/legal/epl-v10.html' url='http://www.eclipse.org/legal/epl-v10.html'>
        Copyright (c) 2005, 2015 IBM Corporation and others.&#xA;All rights reserved.   This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html
      </copyright>
    </unit>
    <unit id='org.eclipse.gef.sdk.feature.group' version='3.11.0.201606061308' singleton='false'>
      <update id='org.eclipse.gef.sdk.feature.group' range='[0.0.0,3.11.0.201606061308)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.gef.features'/>
        <property name='maven-artifactId' value='org.eclipse.gef.sdk'/>
        <property name='maven-version' value='3.11.0-SNAPSHOT'/>
        <property name='df_LT.featureName' value='GEF (MVC) SDK'/>
        <property name='df_LT.providerName' value='Eclipse GEF'/>
        <property name='df_LT.description' value='Graphical Editing Framework GEF SDK'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2009 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gef.sdk.feature.group' version='3.11.0.201606061308'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.draw2d.sdk.feature.group' range='[3.10.100.201606061308,3.10.100.201606061308]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gef.feature.group' range='[3.11.0.201606061308,3.11.0.201606061308]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gef.source.feature.group' range='[3.11.0.201606061308,3.11.0.201606061308]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gef.examples.ui.pde' range='[3.11.0.201606061308,3.11.0.201606061308]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gef.doc.isv' range='[3.11.0.201606061308,3.11.0.201606061308]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gef.sdk.feature.jar' range='[3.11.0.201606061308,3.11.0.201606061308]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.gmf.runtime.sdk.feature.group' version='1.13.0.202004160913' singleton='false'>
      <update id='org.eclipse.gmf.runtime.sdk.feature.group' range='[0.0.0,1.13.0.202004160913)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/gmf'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.gmf.runtime'/>
        <property name='maven-artifactId' value='org.eclipse.gmf.runtime.sdk'/>
        <property name='maven-version' value='1.13.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='Graphical Modeling Framework (GMF) Runtime SDK'/>
        <property name='df_LT.description' value='Graphical Modeling Framework SDK'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gmf.runtime.sdk.feature.group' version='1.13.0.202004160913'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gmf.feature.group' range='[1.13.0.202004160913,1.13.0.202004160913]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gmf.source.feature.group' range='[1.13.0.202004160913,1.13.0.202004160913]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gmf.examples.runtime.ui.pde.feature.group' range='[1.13.0.202004160913,1.13.0.202004160913]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gmf.examples.runtime.feature.group' range='[1.13.0.202004160913,1.13.0.202004160913]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gmf.runtime.thirdparty.source.feature.group' range='[1.13.0.202004160913,1.13.0.202004160913]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gef.sdk.feature.group' range='3.9.2'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gmf.runtime.notation.sdk.feature.group' range='1.8.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.transaction.sdk.feature.group' range='1.8.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gmf.runtime.sdk' range='[1.7.0.202004160913,1.7.0.202004160913]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gmf.runtime.sdk.feature.jar' range='[1.13.0.202004160913,1.13.0.202004160913]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.eclipse.org/legal/epl-2.0/' url='http://www.eclipse.org/legal/epl-2.0/'>
        Copyright (c) 2008, 2015 IBM Corporation and others.&#xA;This program and the accompanying materials are made&#xA;available under the terms of the Eclipse Public License 2.0&#xA;which is available at https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0
      </copyright>
    </unit>
    <unit id='org.eclipse.jdt.feature.group' version='3.18.500.v20200902-1800' singleton='false'>
      <update id='org.eclipse.jdt.feature.group' range='[0.0.0,3.18.500.v20200902-1800)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.jdt.feature'/>
        <property name='maven-artifactId' value='org.eclipse.jdt'/>
        <property name='maven-version' value='3.18.500-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2020 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.featureName' value='Eclipse Java Development Tools'/>
        <property name='df_LT.description' value='Eclipse Java development tools (binary runtime and user documentation).'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.group' version='3.18.500.v20200902-1800'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='40'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt' range='[3.18.500.v20200902-1800,3.18.500.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.ui' range='[3.7.900.v20200724-1008,3.7.900.v20200724-1008]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.apt.core' range='[3.6.700.v20200828-0941,3.6.700.v20200828-0941]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.apt.ui' range='[3.6.500.v20200828-1336,3.6.500.v20200828-1336]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.apt.pluggable.core' range='[1.2.500.v20200322-1447,1.2.500.v20200322-1447]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.compiler.apt' range='[1.3.1100.v20200828-0941,1.3.1100.v20200828-0941]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.compiler.tool' range='[1.2.1000.v20200828-0941,1.2.1000.v20200828-0941]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core' range='[3.23.0.v20200828-0941,3.23.0.v20200828-0941]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core.formatterapp' range='[1.0.0.v20200119-0748,1.0.0.v20200119-0748]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.annotation' range='[1.1.500.v20200407-1355,1.1.500.v20200407-1355]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.annotation' range='[2.2.600.v20200408-1511,2.2.600.v20200408-1511]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core.manipulation' range='[1.14.100.v20200817-2001,1.14.100.v20200817-2001]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.debug.ui' range='[3.12.0.v20200828-0821,3.12.0.v20200828-0821]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.debug' range='[3.16.0.v20200828-0821,3.16.0.v20200828-0821]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.junit' range='[3.11.900.v20200828-0853,3.11.900.v20200828-0853]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.junit.core' range='[3.10.800.v20200817-1957,3.10.800.v20200817-1957]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.junit.runtime' range='[3.5.300.v20200720-0748,3.5.300.v20200720-0748]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.junit4.runtime' range='[1.1.1300.v20200720-0748,1.1.1300.v20200720-0748]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.junit5.runtime' range='[1.0.1000.v20200720-0748,1.0.1000.v20200720-0748]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.launching' range='[3.18.0.v20200824-1854,3.18.0.v20200824-1854]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.ui' range='[3.21.200.v20200828-0853,3.21.200.v20200828-0853]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit' range='[4.13.0.v20200204-1500,4.13.0.v20200204-1500]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.hamcrest.core' range='[1.3.0.v20180420-1519,1.3.0.v20180420-1519]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit.jupiter.api' range='[5.6.0.v20200203-2009,5.6.0.v20200203-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit.jupiter.engine' range='[5.6.0.v20200203-2009,5.6.0.v20200203-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit.jupiter.migrationsupport' range='[5.6.0.v20200203-2009,5.6.0.v20200203-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit.jupiter.params' range='[5.6.0.v20200203-2009,5.6.0.v20200203-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit.platform.commons' range='[1.6.0.v20200203-2009,1.6.0.v20200203-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit.platform.engine' range='[1.6.0.v20200203-2009,1.6.0.v20200203-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit.platform.launcher' range='[1.6.0.v20200203-2009,1.6.0.v20200203-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit.platform.runner' range='[1.6.0.v20200203-2009,1.6.0.v20200203-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit.platform.suite.api' range='[1.6.0.v20200203-2009,1.6.0.v20200203-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit.vintage.engine' range='[5.6.0.v20200203-2009,5.6.0.v20200203-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.opentest4j' range='[1.2.0.v20190826-0900,1.2.0.v20190826-0900]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apiguardian' range='[1.1.0.v20190826-0900,1.1.0.v20190826-0900]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.doc.user' range='[3.15.800.v20200828-1432,3.15.800.v20200828-1432]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.launching.macosx' range='[3.4.500.v20200116-2251,3.4.500.v20200116-2251]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.launching.ui.macosx' range='[1.2.600.v20200204-1737,1.2.600.v20200204-1737]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.launching' range='[1.2.1000.v20200610-1458,1.2.1000.v20200610-1458]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.jar' range='[3.18.500.v20200902-1800,3.18.500.v20200902-1800]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.m2m.atl.sdk.feature.group' version='4.2.1.v202006221222' singleton='false'>
      <update id='org.eclipse.m2m.atl.sdk.feature.group' range='[0.0.0,4.2.1.v202006221222)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.m2m.atl.features'/>
        <property name='maven-artifactId' value='org.eclipse.m2m.atl.sdk'/>
        <property name='maven-version' value='4.2.1-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2007, 2012 Obeo.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;Contributors:&#xA;Obeo - initial API and implementation'/>
        <property name='df_LT.featureName' value='ATL SDK - ATL Transformation Language SDK'/>
        <property name='df_LT.description' value='ATL SDK includes runtime, source, examples and documentation.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.sdk.feature.group' version='4.2.1.v202006221222'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='32'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.doc.feature.group' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.feature.group' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.examples.feature.group' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.profiler.feature.group' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.emftvm.feature.group' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.examples.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.engine.emfvm.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.adt.debug.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.adt.editor.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.drivers.emf4atl.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.drivers.uml24atl.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.engine.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.engine.vm.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.dsls.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.adt.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.adt.ui.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.core.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.core.emf.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.core.ui.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.core.ui.vm.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.common.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.core.ant.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.engine.emfvm.launch.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.debug.core.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.profiler.core.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.profiler.model.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.profiler.ui.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.profiler.vm.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.profiler.exportmodel.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.profiler.exportmodel.editor.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.profiler.emfvm.source' range='[4.2.1.v202006221222,4.2.1.v202006221222]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2m.atl.sdk.feature.jar' range='[4.2.1.v202006221222,4.2.1.v202006221222]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='%25copyrightURL' url='%25copyrightURL'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.ocl.all.sdk.feature.group' version='5.13.0.v20201208-2229' singleton='false'>
      <update id='org.eclipse.ocl.all.sdk.feature.group' range='[0.0.0,5.13.0.v20201208-2229)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='https://projects.eclipse.org/projects/modeling.mdt.ocl'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.ocl.features'/>
        <property name='maven-artifactId' value='org.eclipse.ocl.all.sdk'/>
        <property name='maven-version' value='5.13.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='OCL Classic SDK: Ecore/UML Parsers,Evaluator,Edit'/>
        <property name='df_LT.description' value='Provides the Parser, Evaluator and Edit support for OCL using Ecore or UML APIs.&#xA;&#xA;Install this if you plan to develop OCL-based applications.  This SDK contains runtimes, EMF edit support, documentation, and source code for OCL.'/>
        <property name='df_LT.providerName' value='Eclipse OCL'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ocl.all.sdk.feature.group' version='5.13.0.v20201208-2229'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ocl.core.sdk.feature.group' range='[5.13.0.v20201208-2229,5.13.0.v20201208-2229]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ocl.doc.feature.group' range='[3.14.400.v20201208-2229,3.14.400.v20201208-2229]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ocl.edit.feature.group' range='[5.13.0.v20201208-2229,5.13.0.v20201208-2229]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ocl.ui.feature.group' range='[2.13.0.v20201208-2229,2.13.0.v20201208-2229]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ocl.all.sdk.feature.jar' range='[5.13.0.v20201208-2229,5.13.0.v20201208-2229]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        [Documentation] Copyright text will be taken from the shared license feature
      </copyright>
    </unit>
    <unit id='org.eclipse.ocl.examples.feature.group' version='6.13.0.v20201208-2229' singleton='false'>
      <update id='org.eclipse.ocl.examples.feature.group' range='[0.0.0,6.13.0.v20201208-2229)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='https://projects.eclipse.org/projects/modeling.mdt.ocl'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.ocl.features'/>
        <property name='maven-artifactId' value='org.eclipse.ocl.examples'/>
        <property name='maven-version' value='6.13.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='OCL Examples and Editors SDK'/>
        <property name='df_LT.description' value='Provides both Classic and Unified OCL and additional example projects.&#xA;&#xA;Install this if you plan to develop OCL-based applications.'/>
        <property name='df_LT.providerName' value='Eclipse OCL'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ocl.examples.feature.group' version='6.13.0.v20201208-2229'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ocl.examples.classic.feature.group' range='[5.13.0.v20201208-2229,5.13.0.v20201208-2229]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ocl.examples.unified.feature.group' range='[4.13.0.v20201208-2229,4.13.0.v20201208-2229]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ocl.examples' range='[3.13.0.v20201208-2229,3.13.0.v20201208-2229]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ocl.examples.feature.jar' range='[6.13.0.v20201208-2229,6.13.0.v20201208-2229]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        [Documentation] Copyright text will be taken from the shared license feature
      </copyright>
    </unit>
    <unit id='org.eclipse.pde.feature.group' version='3.14.500.v20200902-1800' singleton='false'>
      <update id='org.eclipse.pde.feature.group' range='[0.0.0,3.14.500.v20200902-1800)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.pde.feature'/>
        <property name='maven-artifactId' value='org.eclipse.pde'/>
        <property name='maven-version' value='3.14.500-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2015 IBM Corporation and others.&#xA;&#xA;This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.featureName' value='Eclipse Plug-in Development Environment'/>
        <property name='df_LT.description' value='Eclipse plug-in development environment.'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.feature.group' version='3.14.500.v20200902-1800'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='26'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.group' range='[3.15.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde' range='[3.13.1200.v20200902-1800,3.13.1200.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.build' range='[3.10.800.v20200410-1419,3.10.800.v20200410-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.core' range='[3.14.0.v20200817-1143,3.14.0.v20200817-1143]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.junit.runtime' range='[3.5.900.v20200810-0835,3.5.900.v20200810-0835]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.runtime' range='[3.6.900.v20200612-1330,3.6.900.v20200612-1330]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ui' range='[3.12.0.v20200824-1258,3.12.0.v20200824-1258]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.doc.user' range='[3.14.900.v20200902-1022,3.14.900.v20200902-1022]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ui.templates' range='[3.7.0.v20200812-1812,3.7.0.v20200812-1812]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm' range='[8.0.1.v20200420-1007,8.0.1.v20200420-1007]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.tree' range='[8.0.1.v20200420-1007,8.0.1.v20200420-1007]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.api.tools' range='[1.2.0.v20200813-0522,1.2.0.v20200813-0522]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.api.tools.annotations' range='[1.1.400.v20190929-1236,1.1.400.v20190929-1236]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.api.tools.ui' range='[1.2.0.v20200813-0523,1.2.0.v20200813-0523]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.core' range='[1.2.0.v20200813-0526,1.2.0.v20200813-0526]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.ui' range='[1.2.0.v20200813-0954,1.2.0.v20200813-0954]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.launching' range='[3.9.0.v20200812-1037,3.9.0.v20200812-1037]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ua.core' range='[1.2.0.v20200813-0518,1.2.0.v20200813-0518]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ua.ui' range='[1.2.0.v20200813-0519,1.2.0.v20200813-0519]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.trace' range='[1.1.800.v20200106-1301,1.1.800.v20200106-1301]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.annotations' range='[1.2.0.v20200813-0526,1.2.0.v20200813-0526]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.genericeditor.extension' range='[1.1.0.v20200828-0858,1.1.0.v20200828-0858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.lib' range='[1.1.400.v20191119-0943,1.1.400.v20191119-0943]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds1_2.lib' range='[1.0.400.v20191119-0943,1.0.400.v20191119-0943]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tools.layout.spy' range='[1.0.600.v20200608-0818,1.0.600.v20200608-0818]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.feature.jar' range='[3.14.500.v20200902-1800,3.14.500.v20200902-1800]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.platform.feature.group' version='4.17.0.v20200902-1800' singleton='false'>
      <update id='org.eclipse.platform.feature.group' range='[0.0.0,4.17.0.v20200902-1800)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.platform.feature'/>
        <property name='maven-artifactId' value='org.eclipse.platform'/>
        <property name='maven-version' value='4.17.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2020 IBM Corporation and others.'/>
        <property name='df_LT.featureName' value='Eclipse Platform'/>
        <property name='df_LT.description' value='Common OS-independent base of the Eclipse platform. (Binary runtime and user documentation.)'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' version='4.17.0.v20200902-1800'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='72'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.feature.group' range='[4.17.0.v20200902-1800,4.17.0.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.user.ui.feature.group' range='[2.4.900.v20200828-0839,2.4.900.v20200828-0839]' optional='true'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.feature.group' range='[2.3.300.v20200902-1800,2.3.300.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.ant' range='[1.10.8.v20200515-1239,1.10.8.v20200515-1239]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core' range='[3.5.800.v20200608-1251,3.5.800.v20200608-1251]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.jcraft.jsch' range='[0.1.55.v20190404-1902,0.1.55.v20190404-1902]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare.core' range='[3.6.900.v20200412-2017,3.6.900.v20200412-2017]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare' range='[3.7.1100.v20200611-0145,3.7.1100.v20200611-0145]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare.win32' range='[1.2.800.v20200127-1343,1.2.800.v20200127-1343]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filebuffers' range='[3.6.1000.v20200409-1035,3.6.1000.v20200409-1035]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='[1.7.700.v20200110-1734,1.7.700.v20200110-1734]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net' range='[1.3.1000.v20200715-0827,1.3.1000.v20200715-0827]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86_64' range='[1.2.400.v20190924-1023,1.2.400.v20190924-1023]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86_64' range='[1.1.500.v20190925-1337,1.1.500.v20190925-1337]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='[3.13.800.v20200706-2152,3.13.800.v20200706-2152]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' range='[3.5.300.v20190708-1141,3.5.300.v20190708-1141]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.core' range='[3.16.0.v20200828-0817,3.16.0.v20200828-0817]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.ui' range='[3.14.600.v20200828-0817,3.14.600.v20200828-0817]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.ide' range='[3.15.100.v20200323-2111,3.15.100.v20200323-2111]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.event' range='[1.5.500.v20200616-0800,1.5.500.v20200616-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.core.refactoring' range='[3.11.100.v20200720-0748,3.11.100.v20200720-0748]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.ui.refactoring' range='[3.11.100.v20200817-1715,3.11.100.v20200817-1715]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform' range='[4.17.0.v20200902-1800,4.17.0.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.doc.user' range='[4.17.0.v20200831-0727,4.17.0.v20200831-0727]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.search' range='[3.12.0.v20200727-2017,3.12.0.v20200727-2017]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.quicksearch' range='[1.0.300.v20200519-2023,1.0.300.v20200519-2023]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.core' range='[3.8.1100.v20200806-0621,3.8.1100.v20200806-0621]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.ui' range='[3.8.1000.v20200806-0621,3.8.1000.v20200806-0621]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text' range='[3.10.300.v20200807-0831,3.10.300.v20200807-0831]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' range='[3.16.400.v20200807-0831,3.16.400.v20200807-0831]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jsch.core' range='[1.3.900.v20200422-1935,1.3.900.v20200422-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jsch.ui' range='[1.3.1000.v20200610-0847,1.3.1000.v20200610-0847]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.console' range='[3.9.300.v20200828-0817,3.9.300.v20200828-0817]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.intro' range='[3.5.1100.v20200828-0803,3.5.1100.v20200828-0803]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.intro.universal' range='[3.4.0.v20200805-1259,3.4.0.v20200805-1259]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cheatsheets' range='[3.7.0.v20200805-2057,3.7.0.v20200805-2057]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.browser' range='[3.6.900.v20200807-1330,3.6.900.v20200807-1330]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.genericeditor' range='[1.1.800.v20200828-1000,1.1.800.v20200828-1000]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.monitoring' range='[1.1.800.v20200820-1401,1.1.800.v20200820-1401]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator' range='[3.9.400.v20200723-2304,3.9.400.v20200723-2304]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator.resources' range='[3.7.400.v20200722-0751,3.7.400.v20200722-0751]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net' range='[1.3.800.v20200422-1935,1.3.800.v20200422-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.texteditor' range='[3.15.0.v20200812-2334,3.15.0.v20200812-2334]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views' range='[3.10.400.v20200611-1719,3.10.400.v20200611-1719]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.editors' range='[3.13.300.v20200812-2334,3.13.300.v20200812-2334]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.externaltools' range='[3.4.800.v20200612-0848,3.4.800.v20200612-0848]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' range='[3.17.200.v20200808-0622,3.17.200.v20200808-0622]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide.application' range='[1.3.800.v20200713-0938,1.3.800.v20200713-0938]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.win32' range='[3.4.400.v20200414-1247,3.4.400.v20200414-1247]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64' range='[1.2.300.v20180828-0158,1.2.300.v20180828-0158]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx' range='[1.3.200.v20190903-0945,1.3.200.v20190903-0945]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.win32.x86_64' range='[3.5.400.v20190812-0909,3.5.400.v20190812-0909]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86_64' range='[1.4.200.v20190812-0909,1.4.200.v20190812-0909]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.ppc64le' range='[1.4.100.v20180828-0158,1.4.100.v20180828-0158]'>
          <filter>
            (&amp;(osgi.arch=ppc64le)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.aarch64' range='[1.4.100.v20200805-0859,1.4.100.v20200805-0859]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables' range='[3.4.800.v20200120-1101,3.4.800.v20200120-1101]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms' range='[3.10.0.v20200727-0948,3.10.0.v20200727-0948]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.properties.tabbed' range='[3.8.1000.v20200609-0849,3.8.1000.v20200609-0849]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' range='[1.3.500.v20200114-1637,1.3.500.v20200114-1637]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.ui' range='[1.2.700.v20200807-1518,1.2.700.v20200807-1518]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.win32.x86_64' range='[1.1.200.v20190812-0919,1.1.200.v20190812-0919]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.macosx' range='[1.101.200.v20190903-0934,1.101.200.v20190903-0934]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.linux.x86_64' range='[1.1.300.v20190830-1238,1.1.300.v20190830-1238]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.externaltools' range='[1.1.700.v20200416-1310,1.1.700.v20200416-1310]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes' range='[1.2.1100.v20200825-0757,1.2.1100.v20200825-0757]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='[3.19.0.v20200724-1004,3.19.0.v20200724-1004]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.intro.quicklinks' range='[1.1.0.v20200724-0708,1.1.0.v20200724-0708]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.genericeditor.diff.extension' range='[1.0.600.v20200212-1524,1.0.600.v20200212-1524]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.urischeme' range='[1.1.100.v20200729-2048,1.1.100.v20200729-2048]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.log' range='[1.2.1200.v20200828-0938,1.2.1200.v20200828-0938]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.jar' range='[4.17.0.v20200902-1800,4.17.0.v20200902-1800]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform_root' range='[4.17.0.v20200902-1800,4.17.0.v20200902-1800]'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.platform.ide' version='4.17.0.I20200902-1800'>
      <update id='org.eclipse.platform.ide' range='[4.0.0,4.17.0.I20200902-1800)' severity='0' description='An update for 4.x generation Eclipse Platform.'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Eclipse Platform'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='org.eclipse.equinox.p2.description' value='4.17 Release of the Eclipse Platform.'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.ide' version='4.17.0.I20200902-1800'/>
      </provides>
      <requires size='10'>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' range='[4.17.0.v20200902-1800,4.17.0.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.user.ui.feature.group' range='[2.4.900.v20200828-0839,2.4.900.v20200828-0839]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.configuration' range='[4.17.0.I20200902-1800,4.17.0.I20200902-1800]'/>
        <required namespace='osgi.ee' name='JavaSE' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.configuration.macosx' range='[1.0.0,1.0.0]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.configuration' range='[1.0.0,1.0.0]'>
          <filter>
            (!(osgi.os=macosx))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.application' range='[4.17.0.I20200902-1800,4.17.0.I20200902-1800]'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='configure'>
            addRepository(type:0,location:http${#58}//download.eclipse.org/eclipse/updates/4.17,name:The Eclipse Project Updates);addRepository(type:1,location:http${#58}//download.eclipse.org/eclipse/updates/4.17,name:The Eclipse Project Updates);addRepository(type:0,location:http${#58}//download.eclipse.org/releases/2020-09,name:2020-09);addRepository(type:1,location:http${#58}//download.eclipse.org/releases/2020-09,name:2020-09);mkdir(path:${installFolder}/dropins);
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='http://eclipse.org/legal/epl/notice.php' url='http://eclipse.org/legal/epl/notice.php'>
          Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;    delivering, extending, and upgrading the Content. Typical modules may&#xA;    include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;    features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;    (Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;    associated material. Each Feature may be packaged as a sub-directory in a&#xA;    directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;    contain a list of the names and version numbers of the Plug-ins and/or&#xA;    Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;    Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;    version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;    http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;    http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;    http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;    http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;    http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;    http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;    execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;    intent of installing, extending or updating the functionality of an&#xA;    Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;    party Installable Software or a portion thereof to be accessed and copied to&#xA;    the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;    conditions that govern the use of the Installable Software (&quot;Installable&#xA;    Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;    accessed from the Target Machine in accordance with the Specification. Such&#xA;    Installable Software Agreement must inform the user of the terms and&#xA;    conditions that govern the Installable Software and must solicit acceptance&#xA;    by the end user in the manner prescribed in such Installable&#xA;    Software Agreement. Upon such indication of agreement by the user, the&#xA;    provisioning Technology will complete installation of the&#xA;    Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.
        </license>
      </licenses>
    </unit>
    <unit id='org.eclipse.platform.ide.executable.win32.win32.x86_64' version='4.17.0.I20200902-1800'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.ide.executable.win32.win32.x86_64' version='4.17.0.I20200902-1800'/>
        <provided namespace='toolingorg.eclipse.platform.ide' name='org.eclipse.platform.ide.executable' version='4.17.0.I20200902-1800'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.platform.ide.executable.win32.win32.x86_64' version='4.17.0.I20200902-1800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='org.eclipse.platform_root' version='4.17.0.v20200902-1800'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform_root' version='4.17.0.v20200902-1800'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.platform_root' version='4.17.0.v20200902-1800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.rcp.feature.group' version='4.17.0.v20200902-1800' singleton='false'>
      <update id='org.eclipse.rcp.feature.group' range='[0.0.0,4.17.0.v20200902-1800)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.rcp.feature'/>
        <property name='maven-artifactId' value='org.eclipse.rcp'/>
        <property name='maven-version' value='4.17.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2013 Eclipse contributors and others.'/>
        <property name='df_LT.featureName' value='Eclipse RCP'/>
        <property name='df_LT.description' value='Rich Client Platform'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.feature.group' version='4.17.0.v20200902-1800'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.rcp.feature.group' range='[4.17.0.v20200831-1002,4.17.0.v20200831-1002]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help' range='[3.8.800.v20200525-0755,3.8.800.v20200525-0755]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='[3.118.0.v20200807-0902,3.118.0.v20200807-0902]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench' range='[3.120.0.v20200829-1411,3.120.0.v20200829-1411]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.configurator' range='[3.4.600.v20200422-1910,3.4.600.v20200422-1910]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp' range='[4.17.0.v20200902-1800,4.17.0.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa' range='[1.2.400.v20191217-1850,1.2.400.v20191217-1850]'>
          <filter>
            (&amp;(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.feature.jar' range='[4.17.0.v20200902-1800,4.17.0.v20200902-1800]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp_root' range='[4.17.0.v20200902-1800,4.17.0.v20200902-1800]'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.rcp_root' version='4.17.0.v20200902-1800'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp_root' version='4.17.0.v20200902-1800'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.rcp_root' version='4.17.0.v20200902-1800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.sdk.feature.group' version='4.17.0.v20200902-1800' singleton='false'>
      <update id='org.eclipse.sdk.feature.group' range='[0.0.0,4.17.0.v20200902-1800)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.sdk.feature'/>
        <property name='maven-artifactId' value='org.eclipse.sdk'/>
        <property name='maven-version' value='4.17.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2020 Eclipse contributors and others.'/>
        <property name='df_LT.featureName' value='Eclipse Project SDK'/>
        <property name='df_LT.description' value='SDK for Eclipse.'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sdk.feature.group' version='4.17.0.v20200902-1800'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' range='[4.17.0.v20200902-1800,4.17.0.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.source.feature.group' range='[4.17.0.v20200902-1800,4.17.0.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.group' range='[3.18.500.v20200902-1800,3.18.500.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.source.feature.group' range='[3.18.500.v20200902-1800,3.18.500.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.feature.group' range='[3.14.500.v20200902-1800,3.14.500.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.source.feature.group' range='[3.14.500.v20200902-1800,3.14.500.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.feature.group' range='[2.3.300.v20200902-1800,2.3.300.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.source.feature.group' range='[2.3.300.v20200902-1800,2.3.300.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.source.feature.group' range='[2.7.0,3.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.source.feature.group' range='[2.7.0,3.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.core.feature.source.feature.group' range='[1.4.0,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.core.ssl.feature.source.feature.group' range='[1.1.0,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.feature.source.feature.group' range='[3.13.7,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.httpclient45.feature.source.feature.group' range='[1.0.0,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.ssl.feature.source.feature.group' range='[1.1.0,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sdk' range='[4.17.0.v20200902-1800,4.17.0.v20200902-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sdk.feature.jar' range='[4.17.0.v20200902-1800,4.17.0.v20200902-1800]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.sirius.specifier.feature.group' version='6.4.1.202012210908' singleton='false'>
      <update id='org.eclipse.sirius.specifier.feature.group' range='[0.0.0,6.4.1.202012210908)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='Sirius Specifier Environment.&#xA;Install this if you want to create your own Sirius-based modelers.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/sirius'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.sirius'/>
        <property name='maven-artifactId' value='org.eclipse.sirius.specifier'/>
        <property name='maven-version' value='6.4.1-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2015 Obeo and others.&#xA;This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;Obeo - initial API and implementation'/>
        <property name='df_LT.featureName' value='Sirius Specifier Environment'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.specifier.feature.group' version='6.4.1.202012210908'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='59'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gmf.feature.group' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.common' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.common.acceleo.aql' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.common.acceleo.aql.ide' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.common.acceleo.mtl' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.common.acceleo.mtl.ide' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.common.ui' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.common.ui.ext' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.diagram' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.diagram.formatdata' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.diagram.sequence' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.diagram.sequence.edit' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.diagram.sequence.ui' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.diagram.ui' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.diagram.ui.ext' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.doc' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ecore.extender' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.editor' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.editor.diagram' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.editor.sequence' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.editor.table' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.editor.tree' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ext.base' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ext.draw2d' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ext.e3' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ext.e3.ui' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ext.emf' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ext.emf.edit' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ext.emf.tx' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ext.emf.ui' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ext.gef' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ext.gmf.notation' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ext.gmf.runtime' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ext.jface' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ext.swt' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.interpreter' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.synchronizer' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.table' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.table.ui' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.table.ui.ext' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.tree' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.tree.ui' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.tree.ui.ext' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ui' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ui.editor' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ui.ext' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.common.interpreter' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.properties' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.properties.core' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.properties.edit' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.properties.ext.widgets.reference' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.properties.ext.widgets.reference.edit' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.editor.properties' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.editor.properties.ext.widgets.reference' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ui.properties' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ui.properties.ext.widgets.reference' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.ext.ide' range='[6.4.1.202012210908,6.4.1.202012210908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.specifier.feature.jar' range='[6.4.1.202012210908,6.4.1.202012210908]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.uml2.sdk.feature.group' version='5.5.1.v20200302-1312' singleton='false'>
      <update id='org.eclipse.uml2.sdk.feature.group' range='[0.0.0,5.5.1.v20200302-1312)' severity='0'/>
      <properties size='11'>
        <property name='org.eclipse.equinox.p2.name' value='%feature.label'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%feature.provider-name'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.uml2.features'/>
        <property name='maven-artifactId' value='org.eclipse.uml2.sdk'/>
        <property name='maven-version' value='5.5.1-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.feature.provider-name' value='Eclipse Modeling Project'/>
        <property name='df_LT.feature.label' value='UML2 Extender SDK'/>
        <property name='df_LT.description' value='Developer resources (documentation, source code, examples) for the run-time APIs, editors, and code generation for the Unified Modeling Language 2.x.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.uml2.sdk.feature.group' version='5.5.1.v20200302-1312'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.uml2.feature.group' range='[5.5.1.v20200302-1312,5.5.1.v20200302-1312]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.uml2.examples.feature.group' range='[5.5.0.v20200302-1312,5.5.0.v20200302-1312]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.uml2.doc.feature.group' range='[5.5.0.v20200302-1312,5.5.0.v20200302-1312]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.uml2.sdk' range='[5.5.1.v20200302-1312,5.5.1.v20200302-1312]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.uml2.sdk.feature.jar' range='[5.5.1.v20200302-1312,5.5.1.v20200302-1312]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.eclipse.org/legal/epl-v20.html' url='http://www.eclipse.org/legal/epl-v20.html'>
        Copyright (c) 2003, 2020 IBM Corporation, Embarcadero Technologies, CEA, and others.&#xA;All rights reserved.   This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v2.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v20.html
      </copyright>
    </unit>
    <unit id='org.eclipse.xsd.sdk.feature.group' version='2.23.0.v20200723-0820' singleton='false'>
      <update id='org.eclipse.xsd.sdk.feature.group' range='[0.0.0,2.23.0.v20200723-0820)' severity='0'/>
      <properties size='11'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.features'/>
        <property name='maven-artifactId' value='org.eclipse.xsd.sdk'/>
        <property name='maven-version' value='2.23.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='XSD - XML Schema Definition SDK'/>
        <property name='df_LT.description' value='The full SDK for XSD, including source and documentation.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.sdk.feature.group' version='2.23.0.v20200723-0820'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.feature.group' range='[2.19.0.v20200723-0820,2.19.0.v20200723-0820]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.source.feature.group' range='[2.19.0.v20200723-0820,2.19.0.v20200723-0820]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.ecore.converter.feature.group' range='[2.12.0.v20200324-0723,2.12.0.v20200324-0723]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.ecore.converter.source.feature.group' range='[2.12.0.v20200324-0723,2.12.0.v20200324-0723]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.edit.feature.group' range='[2.13.0.v20200723-0820,2.13.0.v20200723-0820]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.edit.source.feature.group' range='[2.13.0.v20200723-0820,2.13.0.v20200723-0820]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.editor.feature.group' range='[2.13.0.v20190323-1100,2.13.0.v20190323-1100]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.editor.source.feature.group' range='[2.13.0.v20190323-1100,2.13.0.v20190323-1100]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.mapping.feature.group' range='[2.13.0.v20200723-0820,2.13.0.v20200723-0820]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.mapping.source.feature.group' range='[2.13.0.v20200723-0820,2.13.0.v20200723-0820]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.mapping.editor.feature.group' range='[2.13.0.v20190323-1100,2.13.0.v20190323-1100]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.mapping.editor.source.feature.group' range='[2.13.0.v20190323-1100,2.13.0.v20190323-1100]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.doc.feature.group' range='[2.19.0.v20200630-0517,2.19.0.v20200630-0517]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.example.installer' range='[1.4.0.v20180706-1143,1.4.0.v20180706-1143]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.sdk.feature.jar' range='[2.23.0.v20200723-0820,2.23.0.v20200723-0820]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.eclipse.org/legal/epl-v20.html' url='http://www.eclipse.org/legal/epl-v20.html'>
        Copyright (c) 2002-2018 IBM Corporation and others.&#xA;All rights reserved.   This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v2.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v20.html
      </copyright>
    </unit>
    <unit id='org.eclipse.xtext.sdk.feature.group' version='2.23.0.v20200831-0926' singleton='false'>
      <update id='org.eclipse.xtext.sdk.feature.group' range='[0.0.0,2.23.0.v20200831-0926)' severity='0'/>
      <properties size='11'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.xtext'/>
        <property name='maven-artifactId' value='org.eclipse.xtext.sdk'/>
        <property name='maven-version' value='2.23.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='Xtext Complete SDK'/>
        <property name='df_LT.description' value='The full Software Development Kit. Includes everything you need to develop programming languages and domain specific languages.'/>
        <property name='df_LT.providerName' value='Eclipse Xtext'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.sdk.feature.group' version='2.23.0.v20200831-0926'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.docs.feature.group' range='[2.23.0.v20200831-0926,2.23.0.v20200831-0926]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.runtime.feature.group' range='[2.23.0.v20200831-0926,2.23.0.v20200831-0926]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.redist.feature.group' range='[2.23.0.v20200831-0926,2.23.0.v20200831-0926]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.examples.feature.group' range='[2.23.0.v20200831-0926,2.23.0.v20200831-0926]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui.feature.group' range='[2.23.0.v20200831-0926,2.23.0.v20200831-0926]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xbase.feature.group' range='[2.23.0.v20200831-0926,2.23.0.v20200831-0926]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xbase.lib.feature.group' range='[2.23.0.v20200831-0726,2.23.0.v20200831-0726]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xtext.ui.feature.group' range='[2.23.0.v20200831-0926,2.23.0.v20200831-0926]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtend.sdk.feature.group' range='[2.23.0.v20200831-0926,2.23.0.v20200831-0926]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore' range='2.20.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common' range='2.17.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.source' range='2.20.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.source' range='2.17.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.language.sdk.feature.group' range='2.11.3'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.purexbase' range='[2.23.0.v20200831-0745,2.23.0.v20200831-0745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.purexbase.source' range='[2.23.0.v20200831-0745,2.23.0.v20200831-0745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.purexbase.ide' range='[2.23.0.v20200831-0745,2.23.0.v20200831-0745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.purexbase.ide.source' range='[2.23.0.v20200831-0745,2.23.0.v20200831-0745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.purexbase.ui' range='[2.23.0.v20200831-0808,2.23.0.v20200831-0808]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.purexbase.ui.source' range='[2.23.0.v20200831-0808,2.23.0.v20200831-0808]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.sdk.feature.jar' range='[2.23.0.v20200831-0926,2.23.0.v20200831-0926]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2016, 2018 Xtext Committers and Contributors.&#xA;&#xA;This program and the accompanying materials &#xA;are made available under the terms of the Eclipse Public License 2.0 &#xA;which is available at http://www.eclipse.org/legal/epl-2.0.&#xA;&#xA;SPDX-License-Identifier: EPL-2.0
      </copyright>
    </unit>
  </units>
  <iusProperties size='38'>
    <iuProperties id='SharedProfile_C__Users_thoma_gls-v2020_eclipse-gls' version='1.0.0.1695221449237'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='epp.package.modeling' version='4.17.0.20200910-1200'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='epp.package.modeling.executable.win32.win32.x86_64' version='4.17.0.20200910-1200'>
      <properties size='3'>
        <property name='unzipped|@artifact|C:\Users\thoma\gls-v2020\eclipse-gls' value='C:\Users\thoma\gls-v2020\eclipse-gls\eclipse.exe|C:\Users\thoma\gls-v2020\eclipse-gls\eclipsec.exe|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.acceleo.feature.group' version='3.7.12.202211151354'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.e4.core.tools.feature.feature.group' version='4.18.0.v20201026-0947'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.cdo.epp.feature.group' version='4.11.0.v20200902-0811'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.compare.diagram.sirius.source.feature.group' version='3.3.12.202008311302'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.compare.ide.ui.source.feature.group' version='3.3.12.202008311302'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.compare.source.feature.group' version='3.3.12.202008311302'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.ecoretools.design.feature.group' version='3.3.2.201909230743'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.ecoretools.design_root' version='3.3.2.201909230743'>
      <properties size='3'>
        <property name='unzipped|@artifact|C:\Users\thoma\gls-v2020\eclipse-gls' value='C:\Users\thoma\gls-v2020\eclipse-gls\notice.html|C:\Users\thoma\gls-v2020\eclipse-gls\epl-v10.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.ecoretools.sdk.feature.group' version='3.3.2.201909230743'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.ecoretools.sdk_root' version='3.3.2.201909230743'>
      <properties size='3'>
        <property name='unzipped|@artifact|C:\Users\thoma\gls-v2020\eclipse-gls' value='C:\Users\thoma\gls-v2020\eclipse-gls\epl-v10.html|C:\Users\thoma\gls-v2020\eclipse-gls\notice.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.feature.group' version='2.23.0.v20200822-0801'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.parsley.sdk.feature.group' version='1.12.0.v20200831-1344'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.parsley.sdk.source.feature.group' version='1.12.0.v20200831-1344'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.query.sdk.feature.group' version='1.12.0.201805030653'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.sdk.feature.group' version='2.23.0.v20200822-0801'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.transaction.sdk.feature.group' version='1.12.0.201805140824'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.validation.sdk.feature.group' version='1.12.2.202008210805'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.gef.sdk.feature.group' version='3.11.0.201606061308'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.gmf.runtime.sdk.feature.group' version='1.13.0.202004160913'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.jdt.feature.group' version='3.18.500.v20200902-1800'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.m2m.atl.sdk.feature.group' version='4.2.1.v202006221222'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.ocl.all.sdk.feature.group' version='5.13.0.v20201208-2229'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.ocl.examples.feature.group' version='6.13.0.v20201208-2229'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.pde.feature.group' version='3.14.500.v20200902-1800'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.platform.feature.group' version='4.17.0.v20200902-1800'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.platform.ide' version='4.17.0.I20200902-1800'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.platform.ide.executable.win32.win32.x86_64' version='4.17.0.I20200902-1800'>
      <properties size='3'>
        <property name='unzipped|@artifact|C:\Users\thoma\gls-v2020\eclipse-gls' value='C:\Users\thoma\gls-v2020\eclipse-gls\eclipse.exe|C:\Users\thoma\gls-v2020\eclipse-gls\eclipsec.exe|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.platform_root' version='4.17.0.v20200902-1800'>
      <properties size='3'>
        <property name='unzipped|@artifact|C:\Users\thoma\gls-v2020\eclipse-gls' value='C:\Users\thoma\gls-v2020\eclipse-gls\.eclipseproduct|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.rcp.feature.group' version='4.17.0.v20200902-1800'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.rcp_root' version='4.17.0.v20200902-1800'>
      <properties size='3'>
        <property name='unzipped|@artifact|C:\Users\thoma\gls-v2020\eclipse-gls' value='C:\Users\thoma\gls-v2020\eclipse-gls\readme|C:\Users\thoma\gls-v2020\eclipse-gls\readme\readme_eclipse.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.sdk.feature.group' version='4.17.0.v20200902-1800'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.sirius.specifier.feature.group' version='6.4.1.202012210908'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.uml2.sdk.feature.group' version='5.5.1.v20200302-1312'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.xsd.sdk.feature.group' version='2.23.0.v20200723-0820'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.xtext.sdk.feature.group' version='2.23.0.v20200831-0926'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
